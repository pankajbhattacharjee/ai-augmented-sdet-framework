"""
Executes every AI-generated scenario in ``test_data/ai_scenarios.json``.

The scenarios are *data*, not code: they are produced from natural-language
requirements by ``ai/generate_tests.py`` and consumed here by two generic,
parametrised tests. That keeps the generated artefacts reviewable in a pull
request (a JSON diff) instead of appending untested Python.

Regenerate before running:
    python ai/generate_tests.py && pytest -m ai
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

SCENARIO_FILE = Path(__file__).resolve().parent.parent / "test_data" / "ai_scenarios.json"


def load_scenarios(flow: str | None = None) -> list[dict]:
    if not SCENARIO_FILE.exists():
        pytest.skip("run `python ai/generate_tests.py` first", allow_module_level=True)
    document = json.loads(SCENARIO_FILE.read_text(encoding="utf-8"))
    scenarios = document.get("scenarios", [])
    if flow:
        scenarios = [s for s in scenarios if s["flow"] == flow]
    return scenarios


def _ids(scenarios: list[dict]) -> list[str]:
    return [s["id"] for s in scenarios]


SEARCH_SCENARIOS = load_scenarios("search")
PASSENGER_SCENARIOS = load_scenarios("passenger")


@pytest.mark.ai
@pytest.mark.parametrize("scenario", SEARCH_SCENARIOS, ids=_ids(SEARCH_SCENARIOS))
def test_ai_generated_search_scenario(scenario, search_page):
    """Generated negative scenario against the flight search widget."""
    page = search_page.submit_invalid_search(**scenario["inputs"])
    expected = scenario["expect"]

    assert page.error_banner_visible, f"{scenario['id']}: no validation banner was shown"
    assert page.field_error(expected["field"]) == expected["message"], (
        f"{scenario['id']} ({scenario['requirement']}): "
        f"expected '{expected['message']}' on '{expected['field']}'"
    )
    assert "/flights" not in page.current_url, f"{scenario['id']}: invalid search was allowed through"


@pytest.mark.ai
@pytest.mark.parametrize("scenario", PASSENGER_SCENARIOS, ids=_ids(PASSENGER_SCENARIOS))
def test_ai_generated_passenger_scenario(scenario, passenger_page, passenger_payload):
    """Generated invalid-input scenario against the passenger details form."""
    payload = {**passenger_payload, **scenario["inputs"]}
    page = passenger_page.fill_passenger(**payload)
    blocked = page.submit_and_observe()

    assert blocked, f"{scenario['id']}: invalid details were accepted and the booking progressed"
    expected = scenario["expect"]
    assert page.field_error(expected["field"]) == expected["message"], (
        f"{scenario['id']} ({scenario['requirement']}): "
        f"expected '{expected['message']}' on '{expected['field']}'"
    )
    assert "/confirmation" not in page.current_url, f"{scenario['id']}: invalid details were accepted"
