"""
TC04 — Validate passenger information
TC05 — Check mandatory field validation (passenger form)
TC08 — Test invalid passenger inputs

Blueprint file: test_passenger_details.py / booking_page.py
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest

from app.server import MESSAGES

pytestmark = [pytest.mark.tc04, pytest.mark.tc05, pytest.mark.tc08]

# (field overrides, field that must error, exact expected message)
INVALID_INPUTS = [
    ({"email": "rahul.sharma.example.com"}, "email", MESSAGES["email_invalid"]),
    ({"email": "rahul@example"}, "email", MESSAGES["email_invalid"]),
    ({"email": "rahul@@example.com"}, "email", MESSAGES["email_invalid"]),
    ({"phone": "12345"}, "phone", MESSAGES["phone_invalid"]),
    ({"phone": "abcdefghij"}, "phone", MESSAGES["phone_invalid"]),
    ({"first_name": "Rahul123"}, "first_name", MESSAGES["first_name_invalid"]),
    ({"last_name": "Sharma@"}, "last_name", MESSAGES["last_name_invalid"]),
    ({"dob": (date.today() + timedelta(days=30)).isoformat()}, "dob", MESSAGES["dob_future"]),
    ({"dob": (date.today() - timedelta(days=400)).isoformat()}, "dob", MESSAGES["dob_min_age"]),
]


class TestPassengerInformation:
    """TC04 — the form reflects the flight the passenger selected."""

    def test_passenger_page_shows_selected_flight(self, results_page):
        """TC04 — selection carries flight number, route, date and fare forward."""
        chosen = results_page.flight_numbers()[0]
        page = results_page.select_flight(chosen)

        summary = page.summary
        assert chosen in summary
        assert "BOM" in summary and "DEL" in summary
        assert page.is_visible("passenger-form")

    def test_passenger_form_exposes_all_required_fields(self, passenger_page):
        """TC04 — every field the airline needs to issue a ticket is rendered."""
        for element in (
            "title-select",
            "first-name",
            "last-name",
            "dob",
            "email",
            "phone",
            "seat-select",
            "continue-button",
        ):
            assert passenger_page.is_visible(element), f"{element} missing from passenger form"

    @pytest.mark.smoke
    def test_valid_passenger_details_are_accepted(self, passenger_page, passenger_payload):
        """TC04 — a complete, valid set of details advances the booking."""
        confirmation = passenger_page.fill_passenger(**passenger_payload).submit_expecting_confirmation()

        assert "/confirmation" in confirmation.current_url
        assert confirmation.is_visible("booking-reference")


class TestPassengerMandatoryFields:
    """TC05 — submitting an empty form surfaces every required-field error."""

    def test_empty_passenger_form_shows_all_mandatory_errors(self, passenger_page):
        page = passenger_page.submit_and_expect_error()

        errors = {k: v for k, v in page.errors().items() if v}
        assert errors == {
            "title": MESSAGES["title_required"],
            "first_name": MESSAGES["first_name_required"],
            "last_name": MESSAGES["last_name_required"],
            "dob": MESSAGES["dob_required"],
            "email": MESSAGES["email_required"],
            "phone": MESSAGES["phone_required"],
        }
        assert "/confirmation" not in page.current_url, "invalid form must not reach confirmation"

    @pytest.mark.parametrize(
        "field, omitted_message",
        [
            ("first_name", MESSAGES["first_name_required"]),
            ("last_name", MESSAGES["last_name_required"]),
            ("email", MESSAGES["email_required"]),
            ("phone", MESSAGES["phone_required"]),
            ("dob", MESSAGES["dob_required"]),
        ],
    )
    def test_single_missing_field_is_flagged(
        self, passenger_page, passenger_payload, field, omitted_message
    ):
        """TC05 — one field at a time: only that field errors, others stay clean."""
        payload = dict(passenger_payload)
        payload[field] = ""
        page = passenger_page.fill_passenger(**payload).submit_and_expect_error()

        errors = {k: v for k, v in page.errors().items() if v}
        assert errors == {field: omitted_message}

    def test_entered_values_are_preserved_after_validation_error(self, passenger_page):
        """TC05 — usability: the passenger does not retype valid data."""
        passenger_page.fill_passenger(
            title="Ms", first_name="Anita", last_name="Desai", dob="1988-02-29", phone="9830012345"
        )
        page = passenger_page.submit_and_expect_error()  # email intentionally missing

        assert page.form_values["first_name"] == "Anita"
        assert page.form_values["last_name"] == "Desai"
        assert page.form_values["phone"] == "9830012345"
        assert page.errors()["email"] == MESSAGES["email_required"]


class TestInvalidPassengerInputs:
    """TC08 — malformed values are rejected with a specific message."""

    @pytest.mark.negative
    @pytest.mark.parametrize(
        "overrides, error_field, expected_message",
        INVALID_INPUTS,
        ids=[
            "email-no-at",
            "email-no-tld",
            "email-double-at",
            "phone-too-short",
            "phone-not-numeric",
            "first-name-has-digits",
            "last-name-has-symbol",
            "dob-in-future",
            "passenger-under-2-years",
        ],
    )
    def test_invalid_input_is_rejected(
        self, passenger_page, passenger_payload, overrides, error_field, expected_message
    ):
        payload = {**passenger_payload, **overrides}
        page = passenger_page.fill_passenger(**payload).submit_and_expect_error()

        assert page.errors()[error_field] == expected_message
        assert "/confirmation" not in page.current_url

    @pytest.mark.negative
    def test_seat_preference_is_optional(self, passenger_page, passenger_payload):
        """TC08 — optional field left at default must not block the booking."""
        payload = {**passenger_payload, "seat": None}
        confirmation = passenger_page.fill_passenger(**payload).submit_expecting_confirmation()

        assert "/confirmation" in confirmation.current_url
        assert confirmation.details()["seat"] == "No preference"
