"""
TC05 — Check mandatory field validation across the whole booking funnel
TC07 — Validate booking confirmation

Blueprint file: test_booking.py / booking_page.py
"""

from __future__ import annotations

import pytest

from app.server import MESSAGES
from pages.booking_confirmation_page import BookingConfirmationPage
from pages.flight_search_page import FlightSearchPage

pytestmark = [pytest.mark.tc05, pytest.mark.tc07]


def _book(search_page, future_date, payload, flight_number=None):
    """Drive the full funnel once and return the confirmation page object."""
    results = search_page.search_flights("BOM", "DEL", future_date)
    details = results.select_flight(flight_number) if flight_number else results.select_first_flight()
    return details.fill_passenger(**payload).submit_expecting_confirmation()


class TestBookingConfirmation:
    """TC07 — a successful booking produces a trustworthy confirmation."""

    @pytest.mark.smoke
    def test_complete_booking_reaches_confirmation(self, confirmation_page):
        """TC07 — end-to-end: search -> select -> details -> confirmation."""
        assert "/confirmation" in confirmation_page.current_url
        assert confirmation_page.heading == "Booking confirmed"
        assert confirmation_page.success_banner_visible

    def test_confirmation_shows_a_well_formed_booking_reference(self, confirmation_page):
        """TC07 — a PNR is generated and matches the airline's format."""
        reference = confirmation_page.booking_reference

        assert reference
        assert confirmation_page.is_reference_well_formed, f"unexpected PNR format: {reference}"

    def test_confirmation_itinerary_matches_the_selection(
        self, search_page, future_date, passenger_payload
    ):
        """TC07 — the confirmed flight is the flight that was chosen (not just the first)."""
        results = search_page.search_flights("BOM", "DEL", future_date)
        chosen_flight = results.flight_numbers()[1]
        confirmation = results.select_flight(chosen_flight).fill_passenger(
            **passenger_payload
        ).submit_expecting_confirmation()

        assert confirmation.details()["flight"] == chosen_flight

    def test_confirmation_shows_passenger_and_contact_details(
        self, confirmation_page, passenger_payload
    ):
        """TC07 — passenger name and seat preference are echoed back correctly."""
        details = confirmation_page.details()
        expected_name = (
            f"{passenger_payload['title']} {passenger_payload['first_name']} "
            f"{passenger_payload['last_name']}"
        )

        assert details["passenger"] == expected_name
        assert details["seat"] == passenger_payload["seat"]
        assert "₹" in details["fare"]
        assert details["route"].count("→") == 1

    def test_booking_reference_is_stable_for_same_passenger_and_flight(
        self, search_page, future_date, passenger_payload
    ):
        """TC07 — identical input yields an identical PNR (no random drift in CI)."""
        pnr_one = _book(search_page, future_date, passenger_payload).booking_reference
        pnr_two = _book(search_page, future_date, passenger_payload).booking_reference

        assert pnr_one == pnr_two

    def test_book_another_flight_returns_to_search(self, confirmation_page):
        """TC07 — the confirmation's primary action restarts the funnel."""
        confirmation_page.book_another_flight()
        confirmation_page.waits_for_url("/")

        assert confirmation_page.is_visible("search-form")


class TestBookingFunnelGuards:
    """TC05 — the funnel cannot be short-circuited or submitted half-empty."""

    @pytest.mark.negative
    def test_passenger_page_without_a_flight_redirects_home(self, driver, base_url):
        """TC05 — deep-linking to passenger details without a flight is blocked."""
        driver.get(f"{base_url}/passenger")
        page = FlightSearchPage(driver, base_url)
        page.waits_for_url("/passenger")

        assert driver.current_url.rstrip("/") == base_url
        assert page.is_visible("search-form")

    @pytest.mark.negative
    def test_confirmation_without_booking_reference_redirects_home(self, driver, base_url):
        """TC07 — confirmation cannot be forged by guessing the URL."""
        driver.get(f"{base_url}/confirmation")
        page = FlightSearchPage(driver, base_url)

        assert page.is_visible("search-form"), "expected the booking widget after the redirect"
        assert "/confirmation" not in driver.current_url

    @pytest.mark.negative
    def test_incomplete_passenger_details_never_produces_a_pnr(self, passenger_page):
        """TC05 — no PNR is issued while validation errors remain."""
        passenger_page.fill_passenger(title="Mr", first_name="Rahul")  # last name missing
        page = passenger_page.submit_and_expect_error()

        assert page.errors()["last_name"] == MESSAGES["last_name_required"]
        assert not page.is_present("booking-reference", timeout=1)
        assert "/confirmation" not in page.current_url
