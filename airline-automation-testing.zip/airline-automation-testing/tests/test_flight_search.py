"""
TC02 — Search flights between two cities
TC03 — Select departure date
TC05 — Mandatory field validation (search widget)
TC06 — Verify flight search results

Blueprint file: test_flight_search.py / flight_search_page.py
"""

from __future__ import annotations

import re
from datetime import date, timedelta

import pytest

from app.server import MESSAGES

pytestmark = [pytest.mark.tc02, pytest.mark.tc03, pytest.mark.tc05, pytest.mark.tc06]


# --------------------------------------------------------------------------- #
# TC02 — search flights between two cities
# --------------------------------------------------------------------------- #

class TestFlightSearch:
    @pytest.mark.smoke
    def test_search_flights_between_two_cities(self, search_page, future_date):
        """TC02 — BOM -> DEL returns the results page for exactly that route."""
        results = search_page.search_flights("BOM", "DEL", future_date)

        assert "/flights" in results.current_url
        assert "origin=BOM" in results.current_url
        assert "destination=DEL" in results.current_url
        assert results.has_results, "expected a schedule table for a served route"
        assert "Mumbai (BOM)" in results.route_summary
        assert "Delhi (DEL)" in results.route_summary

    def test_search_is_route_specific(self, search_page, future_date):
        """TC02 — a different city pair produces a different schedule."""
        bom_del = search_page.search_flights("BOM", "DEL", future_date).flights()
        search_page.open_search()
        ccu_goi = search_page.search_flights("CCU", "GOI", future_date).flights()

        assert bom_del and ccu_goi
        assert [f["number"] for f in bom_del] != [f["number"] for f in ccu_goi]


# --------------------------------------------------------------------------- #
# TC03 — select departure date
# --------------------------------------------------------------------------- #

class TestDepartureDate:
    def test_selected_departure_date_is_retained_and_used(self, search_page, future_date):
        """TC03 — the date chosen in the widget drives the results page."""
        search_page.open_search().select_origin("DEL").select_destination("BLR")
        search_page.enter_departure_date(future_date)

        assert search_page.departure_date_value == future_date, "date widget did not accept the value"

        results = search_page.click_search_for_results()

        assert future_date in results.route_summary
        assert future_date in results.current_url

    @pytest.mark.negative
    def test_past_departure_date_is_rejected(self, search_page):
        """TC03 — a date before today must be blocked."""
        yesterday = (date.today() - timedelta(days=1)).isoformat()
        page = search_page.submit_invalid_search("DEL", "BOM", yesterday)

        assert page.error_banner_visible
        assert page.field_error("departure_date") == MESSAGES["date_past"]
        assert "/flights" not in page.current_url

    @pytest.mark.negative
    def test_todays_date_is_accepted(self, search_page):
        """TC03 — boundary: same-day departure is allowed."""
        today = date.today().isoformat()
        results = search_page.search_flights("DEL", "BOM", today)

        assert results.has_results
        assert today in results.route_summary


# --------------------------------------------------------------------------- #
# TC05 — mandatory field validation on the search widget
# --------------------------------------------------------------------------- #

class TestSearchMandatoryFields:
    @pytest.mark.negative
    def test_search_without_any_criteria_shows_all_errors(self, search_page):
        """TC05 — nothing selected: three field errors plus the alert banner."""
        page = search_page.submit_invalid_search()

        assert page.error_banner_visible
        assert page.field_error("origin") == MESSAGES["origin_required"]
        assert page.field_error("destination") == MESSAGES["destination_required"]
        assert page.field_error("departure_date") == MESSAGES["date_required"]
        assert len(page.all_errors()) == 3

    @pytest.mark.negative
    def test_search_without_destination_is_blocked(self, search_page, future_date):
        """TC05 — the scenario from the project brief: no destination entered."""
        page = search_page.submit_invalid_search(origin="BOM", departure_date=future_date)

        assert page.field_error("destination") == MESSAGES["destination_required"]
        assert page.field_error("origin") == "", "origin was supplied, so it must not error"
        assert "/flights" not in page.current_url

    @pytest.mark.negative
    def test_search_without_origin_is_blocked(self, search_page, future_date):
        page = search_page.submit_invalid_search(destination="DEL", departure_date=future_date)

        assert page.field_error("origin") == MESSAGES["origin_required"]

    @pytest.mark.negative
    def test_search_without_date_is_blocked(self, search_page):
        page = search_page.submit_invalid_search(origin="BOM", destination="DEL")

        assert page.field_error("departure_date") == MESSAGES["date_required"]

    @pytest.mark.negative
    def test_same_origin_and_destination_is_blocked(self, search_page, future_date):
        page = search_page.submit_invalid_search("DEL", "DEL", future_date)

        assert page.field_error("destination") == MESSAGES["same_city"]
        assert "/flights" not in page.current_url


# --------------------------------------------------------------------------- #
# TC06 — verify flight search results
# --------------------------------------------------------------------------- #

class TestFlightResults:
    @pytest.mark.smoke
    def test_results_table_is_populated_and_consistent(self, results_page):
        """TC06 — every row is complete, the count matches, fares are positive."""
        assert results_page.has_results
        flights = results_page.flights()

        assert 3 <= len(flights) <= 4
        assert results_page.result_count == len(flights)
        assert results_page.displayed_count == len(flights)

        for flight in flights:
            assert re.fullmatch(r"SW-\d{3}", flight["number"]), flight["number"]
            assert re.fullmatch(r"\d{2}:\d{2}", flight["departure"])
            assert re.fullmatch(r"\d{2}:\d{2}", flight["arrival"])
            assert re.fullmatch(r"\d+h \d{2}m", flight["duration"])
            assert flight["stops"] in {"Non-stop", "1 stop"}
            assert flight["aircraft"]
            assert flight["fare"].startswith("₹")
            assert flight["fare_value"] > 0

    def test_flight_numbers_are_unique(self, results_page):
        """TC06 — no duplicate rows in one schedule."""
        numbers = results_page.flight_numbers()

        assert len(numbers) == len(set(numbers))

    def test_same_search_returns_deterministic_results(self, search_page, future_date):
        """TC06 — repeatable data keeps the suite (and CI) stable."""
        first = search_page.search_flights("BOM", "DEL", future_date).flights()
        second = search_page.search_flights("BOM", "DEL", future_date).flights()

        assert first == second

    def test_results_are_sorted_by_departure_time(self, results_page):
        """TC06 — schedule order is chronological."""
        departures = [flight["departure"] for flight in results_page.flights()]

        assert departures == sorted(departures)
