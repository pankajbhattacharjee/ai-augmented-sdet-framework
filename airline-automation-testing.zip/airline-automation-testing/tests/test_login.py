"""
TC01 — Open airline booking website.
Plus member-login checks (valid, invalid, empty credentials).

Blueprint files this module covers: test_login.py / login_page.py
"""

from __future__ import annotations

import pytest

from app.server import MESSAGES

pytestmark = [pytest.mark.tc01, pytest.mark.smoke]


class TestWebsiteAvailability:
    """TC01: the booking website loads and exposes the booking entry points."""

    def test_homepage_opens_successfully(self, search_page):
        """TC01 — homepage returns a rendered search widget, not an error page."""
        search_page.open_search()

        assert "SkyWings" in search_page.title
        assert search_page.heading == "Book your flight"
        assert search_page.is_visible("search-form")
        assert search_page.current_url.rstrip("/") == search_page.base_url

    def test_homepage_exposes_all_mandatory_search_controls(self, search_page):
        """TC01 — origin, destination and date widgets are present and usable."""
        search_page.open_search()

        for element in ("origin-select", "destination-select", "departure-date", "search-button"):
            assert search_page.is_visible(element), f"{element} missing from the booking widget"

        assert search_page.is_visible("main-nav")

    def test_homepage_lists_bookable_cities(self, search_page):
        """TC01 — the origin dropdown is populated from the airline's network."""
        search_page.open_search()
        options = search_page.available_cities

        assert options[0] == "Select origin"
        assert len(options) > 5
        assert any("Mumbai (BOM)" in option for option in options)


class TestMemberLogin:
    """Member login — a secondary flow on the same site."""

    def test_login_with_valid_credentials_succeeds(self, login_page):
        login_page.open_login().login("passenger@skywings.test", "Sky@12345")

        assert login_page.is_logged_in
        assert "passenger@skywings.test" in login_page.success_message

    @pytest.mark.negative
    def test_login_with_wrong_password_is_rejected(self, login_page):
        login_page.open_login().login("passenger@skywings.test", "WrongPass1")

        assert login_page.error_message == MESSAGES["login_invalid"]
        assert not login_page.is_logged_in

    @pytest.mark.negative
    @pytest.mark.mandatory
    def test_login_with_empty_credentials_is_rejected(self, login_page):
        """Mandatory-field behaviour on the login form (TC05 pattern)."""
        login_page.open_login().click("login-button")

        assert login_page.error_message == MESSAGES["login_required"]
