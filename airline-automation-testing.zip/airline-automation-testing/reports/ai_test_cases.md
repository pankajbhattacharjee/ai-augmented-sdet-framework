# AI-generated test scenarios

Generated 15 scenarios from natural-language requirements.
Executed by `tests/test_ai_generated.py`.

| Scenario | TC | Flow | Requirement | Expected validation |
| --- | --- | --- | --- | --- |
| `AI-SEARCH-DESTINATION-MISSING` | TC05 | search | REQ-01: A passenger tries to book a flight without entering their destination. | Destination is required |
| `AI-SEARCH-ORIGIN-MISSING` | TC05 | search | REQ-02: A passenger tries to search flights without selecting an origin city. | Origin is required |
| `AI-SEARCH-DATE-MISSING` | TC03 | search | REQ-03: A passenger searches without choosing a departure date. | Departure date is required |
| `AI-SEARCH-DATE-PAST` | TC03 | search | REQ-04: A passenger selects a departure date in the past. | Departure date cannot be in the past |
| `AI-SEARCH-SAME-CITY` | TC02 | search | REQ-05: A passenger picks the same city as origin and destination. | Origin and destination cannot be the same |
| `AI-PASSENGER-EMAIL-NO-AT` | TC08 | passenger | REQ-06: A passenger enters an email address that is missing the @ symbol. | Enter a valid email address |
| `AI-PASSENGER-EMAIL-NO-TLD` | TC08 | passenger | REQ-07: A passenger enters an email address without a domain suffix. | Enter a valid email address |
| `AI-PASSENGER-PHONE-ALPHA` | TC08 | passenger | REQ-08: A passenger enters a mobile number containing letters. | Phone number must be 10 digits |
| `AI-PASSENGER-PHONE-SHORT` | TC08 | passenger | REQ-09: A passenger enters a mobile number shorter than ten digits. | Phone number must be 10 digits |
| `AI-PASSENGER-FIRST-NAME-DIGITS` | TC08 | passenger | REQ-10: A passenger types digits into the first name field. | First name must contain letters only |
| `AI-PASSENGER-LAST-NAME-SYMBOL` | TC08 | passenger | REQ-11: A passenger types a special character into the last name field. | Last name must contain letters only |
| `AI-PASSENGER-DOB-FUTURE` | TC08 | passenger | REQ-12: A passenger enters a date of birth in the future. | Date of birth cannot be in the future |
| `AI-PASSENGER-INFANT-ALONE` | TC08 | passenger | REQ-13: An infant younger than two years is entered as the only passenger. | Passenger must be at least 2 years old |
| `AI-PASSENGER-TITLE-MISSING` | TC05 | passenger | REQ-14: A passenger leaves the title field unselected on the passenger form. | Title is required |
| `AI-PASSENGER-FORM-EMPTY` | TC05 | passenger | REQ-15: A passenger submits the passenger form completely empty. | First name is required |
