# AI analysis of the airline automation run

_Generated 2026-10-30T07:09:13 by `ai/analyze_failures.py`._

## 1. Run summary

| Metric | Value |
| --- | --- |
| Tests | 3 |
| Passed | 0 |
| Failed | 3 |
| Skipped | 0 |
| Wall time (sum of test time) | 13.4s |
| Pass rate | 0.0% |

## 2. Failure triage

| Category | Count | Likely cause | Suggested action |
| --- | --- | --- | --- |
| Timing / synchronisation | 1 | An expected element/state never appeared in time (missing locator or a missing wait). | If the markup changed, fix the page object; if the state arrives late, wait on it explicitly. |
| Validation regression | 1 | Actual validation copy or behaviour differs from the expected message. | Confirm the expected wording in app/server.py MESSAGES; if the copy changed on purpose, update tests; if not, raise a defect. |
| Behavioural regression | 1 | The flow completed but produced a different result than specified. | Compare against the requirement; capture the screenshot in reports/screenshots as evidence. |

### Timing / synchronisation (1)

- **`test_injected_locator_drift`** (tests/test_zz_injected_failures.py)
  - Signature: `selenium.common.exceptions.TimeoutException: Message:`
  - Evidence: see `reports/screenshots/` (files matching `test_injected_locator_drift`)

### Validation regression (1)

- **`test_injected_validation_regression`** (tests/test_zz_injected_failures.py)
  - Signature: `AssertionError: assert 'Destination is required' == 'Please choos...tination city'`
  - Evidence: see `reports/screenshots/` (files matching `test_injected_validation_regression`)

### Behavioural regression (1)

- **`test_injected_behavioural_regression`** (tests/test_zz_injected_failures.py)
  - Signature: `AssertionError: assert False`
  - Evidence: see `reports/screenshots/` (files matching `test_injected_behavioural_regression`)

## 3. Flakiness watch

These failures look like instability rather than product defects — re-run before filing a bug:

- `test_injected_locator_drift`

## 4. Test-case coverage (TC01–TC08)

| TC | Title | Passed | Failed | Status |
| --- | --- | --- | --- | --- |
| TC01 | Open airline booking website | 0 | 0 | **GAP** |
| TC02 | Search flights between two cities | 0 | 0 | **GAP** |
| TC03 | Select departure date | 0 | 0 | **GAP** |
| TC04 | Validate passenger information | 0 | 0 | **GAP** |
| TC05 | Check mandatory field validation | 0 | 0 | **GAP** |
| TC06 | Verify flight search results | 0 | 0 | **GAP** |
| TC07 | Validate booking confirmation | 0 | 3 | FAILING |
| TC08 | Test invalid passenger inputs | 0 | 0 | **GAP** |

## 5. Missing scenarios identified automatically

The application can emit 23 validation messages; the suite asserts all but 4.

### Defensive branches (not reachable through the UI)

These exist as server-side safety nets; testing them would require bypassing the interface, so they are reported for awareness only.

| Rule key | Message | Why the UI cannot reach it |
| --- | --- | --- |
| `date_invalid` | Enter a valid departure date | The date widget is a native ISO input; malformed strings cannot be typed. |
| `no_flights` | No flights available for the selected route | The demo airline schedules every city pair, so the empty state needs a seeded route. |
| `flight_required` | Select a flight before continuing | Booking a flight without one redirects to the search page instead. |
| `dob_max_age` | Enter a valid date of birth | Would need a passenger aged over 120 to trigger. |


## 6. Generated-test health

- No AI-generated scenarios were executed in this run (`pytest -m ai`).
