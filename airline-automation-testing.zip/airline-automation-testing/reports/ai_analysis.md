# AI analysis of the airline automation run

_Generated 2026-10-30T07:11:36 by `ai/analyze_failures.py`._

## 1. Run summary

| Metric | Value |
| --- | --- |
| Tests | 64 |
| Passed | 64 |
| Failed | 0 |
| Skipped | 0 |
| Wall time (sum of test time) | 99.6s |
| Pass rate | 100.0% |

## 2. Failure triage

No failures. Nothing to triage — the funnel is green.

## 3. Flakiness watch

No timing or staleness signatures detected; failures are deterministic.

## 4. Test-case coverage (TC01–TC08)

| TC | Title | Passed | Failed | Status |
| --- | --- | --- | --- | --- |
| TC01 | Open airline booking website | 6 | 0 | covered |
| TC02 | Search flights between two cities | 15 | 0 | covered |
| TC03 | Select departure date | 16 | 0 | covered |
| TC04 | Validate passenger information | 20 | 0 | covered |
| TC05 | Check mandatory field validation | 47 | 0 | covered |
| TC06 | Verify flight search results | 14 | 0 | covered |
| TC07 | Validate booking confirmation | 9 | 0 | covered |
| TC08 | Test invalid passenger inputs | 28 | 0 | covered |

## 5. Missing scenarios identified automatically

The application can emit 23 validation messages; the suite asserts all but 4.

### Defensive branches (not reachable through the UI)

These exist as server-side safety nets; testing them would require bypassing the interface, so they are reported for awareness only.

| Rule key | Message | Why the UI cannot reach it |
| --- | --- | --- |
| `date_invalid` | Enter a valid departure date | The date widget is a native ISO input; malformed strings cannot be typed. |
| `no_flights` | No flights available for the selected route | The demo airline schedules every city pair, so the empty state needs a seeded route. |
| `flight_required` | Select a flight before continuing | Booking a flight without one redirects to the search page instead. |
| `dob_max_age` | Enter a valid date of birth | Would need a passenger aged over 120 to trigger. |


## 6. Generated-test health

- AI-generated scenarios executed: 15
- Failing: 0
