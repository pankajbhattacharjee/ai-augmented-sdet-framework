"""
SkyWings Airlines - demo booking application (System Under Test).

A deliberately small, dependency-light Flask app that mimics the booking flow an
airline website exposes: search -> select flight -> passenger details -> confirmation.
It exists so the Selenium suite has a stable, offline, deterministic target instead
of depending on a third-party demo site that can change or go down.

Run standalone:
    python app/server.py            # http://127.0.0.1:5000
"""

from __future__ import annotations

import hashlib
import os
import random
import re
from datetime import date, datetime

from flask import Flask, redirect, render_template_string, request, url_for

app = Flask(__name__)

# --------------------------------------------------------------------------- #
# Reference data
# --------------------------------------------------------------------------- #

CITIES = [
    {"code": "DEL", "city": "Delhi", "airport": "Indira Gandhi Intl"},
    {"code": "BOM", "city": "Mumbai", "airport": "Chhatrapati Shivaji Maharaj Intl"},
    {"code": "BLR", "city": "Bengaluru", "airport": "Kempegowda Intl"},
    {"code": "CCU", "city": "Kolkata", "airport": "Netaji Subhas Chandra Bose Intl"},
    {"code": "MAA", "city": "Chennai", "airport": "Chennai Intl"},
    {"code": "HYD", "city": "Hyderabad", "airport": "Rajiv Gandhi Intl"},
    {"code": "GOI", "city": "Goa", "airport": "Dabolim"},
    {"code": "JAI", "city": "Jaipur", "airport": "Jaipur Intl"},
]
CITY_BY_CODE = {c["code"]: c for c in CITIES}

DEMO_USER = {"username": "passenger@skywings.test", "password": "Sky@12345"}

# Centralised validation copy. Tests assert against these exact strings, so the
# message wording lives in one place (single source of truth for both app + tests).
MESSAGES = {
    "origin_required": "Origin is required",
    "destination_required": "Destination is required",
    "same_city": "Origin and destination cannot be the same",
    "date_required": "Departure date is required",
    "date_past": "Departure date cannot be in the past",
    "date_invalid": "Enter a valid departure date",
    "no_flights": "No flights available for the selected route",
    "flight_required": "Select a flight before continuing",
    "title_required": "Title is required",
    "first_name_required": "First name is required",
    "first_name_invalid": "First name must contain letters only",
    "last_name_required": "Last name is required",
    "last_name_invalid": "Last name must contain letters only",
    "email_required": "Email is required",
    "email_invalid": "Enter a valid email address",
    "phone_required": "Phone number is required",
    "phone_invalid": "Phone number must be 10 digits",
    "dob_required": "Date of birth is required",
    "dob_future": "Date of birth cannot be in the future",
    "dob_min_age": "Passenger must be at least 2 years old",
    "dob_max_age": "Enter a valid date of birth",
    "login_required": "Username and password are required",
    "login_invalid": "Invalid username or password",
}

EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z .'-]*$")
PHONE_RE = re.compile(r"^[0-9]{10}$")


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def build_flights(origin: str, destination: str, travel_date: str) -> list[dict]:
    """Deterministically generate a small schedule for a route/date pair."""
    seed = int(hashlib.md5(f"{origin}{destination}{travel_date}".encode()).hexdigest(), 16)
    rng = random.Random(seed)
    templates = [
        ("06:15", "08:20", "Airbus A320", 0),
        ("09:40", "11:55", "Boeing 737-800", 1),
        ("13:05", "15:15", "Airbus A321neo", 0),
        ("17:30", "19:45", "Boeing 737 MAX", 1),
        ("21:50", "23:59", "Airbus A320", 0),
    ]
    count = 3 + (seed % 2)  # 3 or 4 departures
    chosen = rng.sample(templates, count)
    chosen.sort(key=lambda t: t[0])
    flights = []
    for idx, (dep, arr, aircraft, stops) in enumerate(chosen):
        base = 3200 + (seed >> (idx * 3)) % 4200
        flights.append(
            {
                "number": f"SW-{100 + (seed >> (idx * 5)) % 800}",
                "departure": dep,
                "arrival": arr,
                "duration": _duration(dep, arr),
                "aircraft": aircraft,
                "stops": "Non-stop" if stops == 0 else "1 stop",
                "fare": base + idx * 350,
            }
        )
    return flights


def _duration(dep: str, arr: str) -> str:
    d = datetime.strptime(dep, "%H:%M")
    a = datetime.strptime(arr, "%H:%M")
    mins = int((a - d).total_seconds() // 60) % (24 * 60)
    return f"{mins // 60}h {mins % 60:02d}m"


def validate_search(form) -> dict[str, str]:
    """Return {field: error message}. Empty dict == valid."""
    errors: dict[str, str] = {}
    origin = (form.get("origin") or "").strip().upper()
    destination = (form.get("destination") or "").strip().upper()
    travel_date = (form.get("departure_date") or "").strip()

    if not origin:
        errors["origin"] = MESSAGES["origin_required"]
    if not destination:
        errors["destination"] = MESSAGES["destination_required"]
    if origin and destination and origin == destination:
        errors["destination"] = MESSAGES["same_city"]
    if not travel_date:
        errors["departure_date"] = MESSAGES["date_required"]
    else:
        try:
            parsed = datetime.strptime(travel_date, "%Y-%m-%d").date()
        except ValueError:
            errors["departure_date"] = MESSAGES["date_invalid"]
        else:
            if parsed < date.today():
                errors["departure_date"] = MESSAGES["date_past"]
    return errors


def validate_passenger(form) -> dict[str, str]:
    """Server-side validation for the passenger details form."""
    errors: dict[str, str] = {}
    title = (form.get("title") or "").strip()
    first = (form.get("first_name") or "").strip()
    last = (form.get("last_name") or "").strip()
    email = (form.get("email") or "").strip()
    phone = (form.get("phone") or "").strip()
    dob = (form.get("dob") or "").strip()

    if not title:
        errors["title"] = MESSAGES["title_required"]

    if not first:
        errors["first_name"] = MESSAGES["first_name_required"]
    elif not NAME_RE.match(first):
        errors["first_name"] = MESSAGES["first_name_invalid"]

    if not last:
        errors["last_name"] = MESSAGES["last_name_required"]
    elif not NAME_RE.match(last):
        errors["last_name"] = MESSAGES["last_name_invalid"]

    if not email:
        errors["email"] = MESSAGES["email_required"]
    elif not EMAIL_RE.match(email):
        errors["email"] = MESSAGES["email_invalid"]

    if not phone:
        errors["phone"] = MESSAGES["phone_required"]
    elif not PHONE_RE.match(phone):
        errors["phone"] = MESSAGES["phone_invalid"]

    if not dob:
        errors["dob"] = MESSAGES["dob_required"]
    else:
        try:
            dob_date = datetime.strptime(dob, "%Y-%m-%d").date()
        except ValueError:
            errors["dob"] = MESSAGES["dob_required"]
        else:
            today = date.today()
            if dob_date > today:
                errors["dob"] = MESSAGES["dob_future"]
            else:
                age = (today - dob_date).days / 365.25
                if age < 2:
                    errors["dob"] = MESSAGES["dob_min_age"]
                elif age > 120:
                    errors["dob"] = MESSAGES["dob_max_age"]
    return errors


def make_pnr(passenger_name: str, flight_number: str) -> str:
    raw = hashlib.sha1(f"{passenger_name}|{flight_number}".upper().encode()).hexdigest()
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    body = "".join(alphabet[int(raw[i : i + 2], 16) % len(alphabet)] for i in range(0, 10, 2))
    return f"SW{body}"


# --------------------------------------------------------------------------- #
# Base layout
# --------------------------------------------------------------------------- #

BASE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{% block title %}SkyWings Airlines{% endblock %}</title>
<style>
  :root { --ink:#0f172a; --muted:#64748b; --line:#e2e8f0; --brand:#0b5cff; --bad:#dc2626; --ok:#047857; }
  * { box-sizing: border-box; }
  body { margin:0; font-family: -apple-system, "Segoe UI", Roboto, Arial, sans-serif; color:var(--ink); background:#f6f8fc; }
  header { background:#0b1a3a; color:#fff; padding:14px 24px; display:flex; align-items:center; gap:22px; }
  header .logo { font-weight:700; letter-spacing:.3px; font-size:18px; }
  header nav a { color:#c8d6f5; text-decoration:none; margin-right:16px; font-size:14px; }
  header nav a:hover { color:#fff; }
  main { max-width: 960px; margin: 26px auto; padding: 0 18px 60px; }
  h1 { font-size:24px; margin:0 0 6px; }
  h2 { font-size:18px; margin:22px 0 10px; }
  .sub { color:var(--muted); font-size:14px; margin:0 0 20px; }
  .card { background:#fff; border:1px solid var(--line); border-radius:12px; padding:20px; box-shadow:0 1px 2px rgba(15,23,42,.04); }
  label { display:block; font-size:13px; font-weight:600; margin-bottom:5px; }
  input, select { width:100%; padding:9px 10px; border:1px solid #cbd5e1; border-radius:8px; font-size:14px; background:#fff; }
  input:focus, select:focus { outline:2px solid #bfd4ff; border-color:var(--brand); }
  .grid { display:grid; gap:14px; }
  .cols-3 { grid-template-columns: repeat(3, 1fr); }
  .cols-2 { grid-template-columns: repeat(2, 1fr); }
  .error { display:block; color:var(--bad); font-size:12.5px; margin-top:4px; min-height:0; }
  .alert { border-radius:8px; padding:10px 12px; font-size:14px; margin-bottom:16px; }
  .alert-error { background:#fef2f2; border:1px solid #fecaca; color:#991b1b; }
  .alert-ok { background:#ecfdf5; border:1px solid #a7f3d0; color:#065f46; }
  button { background:var(--brand); color:#fff; border:0; border-radius:8px; padding:11px 20px; font-size:14.5px; font-weight:600; cursor:pointer; }
  button:hover { background:#0a4fd8; }
  button.secondary { background:#fff; color:var(--brand); border:1px solid var(--brand); }
  table { width:100%; border-collapse:collapse; font-size:14px; }
  th, td { text-align:left; padding:12px 10px; border-bottom:1px solid var(--line); }
  th { font-size:12px; text-transform:uppercase; letter-spacing:.04em; color:var(--muted); }
  .flight-num { font-weight:700; }
  .fare { font-weight:700; white-space:nowrap; }
  .muted { color:var(--muted); font-size:13px; }
  .summary { display:grid; grid-template-columns: 180px 1fr; gap:10px 18px; font-size:14px; }
  .summary dt { color:var(--muted); }
  .summary dd { margin:0; font-weight:600; }
  .pnr { font-size:30px; font-weight:800; letter-spacing:.14em; color:var(--ok); }
  .actions { margin-top:20px; display:flex; gap:12px; align-items:center; }
  footer { color:var(--muted); font-size:12.5px; text-align:center; padding:20px; }
</style>
</head>
<body>
<header>
  <span class="logo">✈ SkyWings</span>
  <nav data-testid="main-nav">
    <a href="{{ url_for('home') }}" data-testid="nav-book">Book a flight</a>
    <a href="{{ url_for('login') }}" data-testid="nav-login">Login</a>
  </nav>
</header>
<main>
{% block content %}{% endblock %}
</main>
<footer>SkyWings Airlines · demo application for automation testing · not a real airline</footer>
</body>
</html>
"""


# --------------------------------------------------------------------------- #
# Home / search
# --------------------------------------------------------------------------- #

HOME = BASE.replace(
    "{% block content %}{% endblock %}",
    """
<h1 data-testid="page-heading">Book your flight</h1>
<p class="sub">Search one-way fares across 8 Indian cities. All fields are mandatory.</p>
{% if errors %}
<div class="alert alert-error" data-testid="search-error-banner" role="alert">
  Please correct the highlighted fields.
</div>
{% endif %}
<div class="card">
  <form method="post" action="{{ url_for('search') }}" data-testid="search-form" novalidate>
    <div class="grid cols-3">
      <div>
        <label for="origin">From</label>
        <select id="origin" name="origin" data-testid="origin-select">
          <option value="">Select origin</option>
          {% for c in cities %}
          <option value="{{ c.code }}" {% if form.get('origin') == c.code %}selected{% endif %}>{{ c.city }} ({{ c.code }})</option>
          {% endfor %}
        </select>
        <span class="error" data-testid="error-origin">{{ errors.get('origin','') }}</span>
      </div>
      <div>
        <label for="destination">To</label>
        <select id="destination" name="destination" data-testid="destination-select">
          <option value="">Select destination</option>
          {% for c in cities %}
          <option value="{{ c.code }}" {% if form.get('destination') == c.code %}selected{% endif %}>{{ c.city }} ({{ c.code }})</option>
          {% endfor %}
        </select>
        <span class="error" data-testid="error-destination">{{ errors.get('destination','') }}</span>
      </div>
      <div>
        <label for="departure-date">Departure date</label>
        <input type="date" id="departure-date" name="departure_date"
               data-testid="departure-date" min="{{ today }}" value="{{ form.get('departure_date','') }}">
        <span class="error" data-testid="error-departure-date">{{ errors.get('departure_date','') }}</span>
      </div>
    </div>
    <div class="actions">
      <button type="submit" data-testid="search-button">Search flights</button>
      <span class="muted">Fares include taxes and fees.</span>
    </div>
  </form>
</div>
""",
)


@app.route("/", methods=["GET"])
def home():
    return render_template_string(
        HOME,
        cities=CITIES,
        errors={},
        form={},
        today=date.today().isoformat(),
    )


@app.route("/search", methods=["POST"])
def search():
    form = request.form.to_dict()
    errors = validate_search(request.form)
    if errors:
        return (
            render_template_string(
                HOME, cities=CITIES, errors=errors, form=form, today=date.today().isoformat()
            ),
                        400,
        )
    origin = form["origin"].strip().upper()
    destination = form["destination"].strip().upper()
    return redirect(
        url_for(
            "flights",
            origin=origin,
            destination=destination,
            departure_date=form["departure_date"].strip(),
        )
    )


# --------------------------------------------------------------------------- #
# Flight results
# --------------------------------------------------------------------------- #

FLIGHTS = BASE.replace(
    "{% block content %}{% endblock %}",
    """
<h1>Available flights</h1>
<p class="sub" data-testid="route-summary">
  {{ origin.city }} ({{ origin.code }}) → {{ destination.city }} ({{ destination.code }})
  · {{ travel_date }}
</p>
{% if flights %}
<div class="card">
  <table data-testid="flight-results">
    <thead>
      <tr>
        <th>Flight</th><th>Departs</th><th>Arrives</th><th>Duration</th>
        <th>Stops</th><th>Aircraft</th><th>Fare</th><th></th>
      </tr>
    </thead>
    <tbody>
      {% for f in flights %}
      <tr data-testid="flight-row" data-flight-number="{{ f.number }}">
        <td class="flight-num" data-testid="flight-number">{{ f.number }}</td>
        <td data-testid="flight-departure">{{ f.departure }}</td>
        <td data-testid="flight-arrival">{{ f.arrival }}</td>
        <td data-testid="flight-duration">{{ f.duration }}</td>
        <td data-testid="flight-stops">{{ f.stops }}</td>
        <td data-testid="flight-aircraft">{{ f.aircraft }}</td>
        <td class="fare" data-testid="flight-fare">₹{{ '{:,}'.format(f.fare) }}</td>
        <td>
          <form method="get" action="{{ url_for('passenger_details') }}" data-testid="select-flight-form">
            <input type="hidden" name="flight" value="{{ f.number }}">
            <input type="hidden" name="origin" value="{{ origin.code }}">
            <input type="hidden" name="destination" value="{{ destination.code }}">
            <input type="hidden" name="departure_date" value="{{ travel_date }}">
            <input type="hidden" name="fare" value="{{ f.fare }}">
            <input type="hidden" name="departure" value="{{ f.departure }}">
            <input type="hidden" name="arrival" value="{{ f.arrival }}">
            <button type="submit" data-testid="select-flight">Select</button>
          </form>
        </td>
      </tr>
      {% endfor %}
    </tbody>
  </table>
</div>
<p class="muted" style="margin-top:12px"><span data-testid="result-count">{{ flights|length }}</span> flights found.</p>
{% else %}
<div class="alert alert-error" data-testid="no-flights-message" role="alert">
  No flights available for the selected route
</div>
{% endif %}
""",
)


@app.route("/flights", methods=["GET"])
def flights():
    origin = (request.args.get("origin") or "").upper()
    destination = (request.args.get("destination") or "").upper()
    travel_date = request.args.get("departure_date") or ""

    if origin not in CITY_BY_CODE or destination not in CITY_BY_CODE:
        return redirect(url_for("home"))

    schedule = build_flights(origin, destination, travel_date)
    return render_template_string(
        FLIGHTS,
        origin=CITY_BY_CODE[origin],
        destination=CITY_BY_CODE[destination],
        travel_date=travel_date,
        flights=schedule,
    )


# --------------------------------------------------------------------------- #
# Passenger details
# --------------------------------------------------------------------------- #

PASSENGER = BASE.replace(
    "{% block content %}{% endblock %}",
    """
<h1>Passenger details</h1>
<p class="sub" data-testid="selected-flight-summary">
  {{ selected.flight }} · {{ selected.origin }} → {{ selected.destination }}
  · {{ selected.departure_date }} · departs {{ selected.departure }} · {{ fare_display }}
</p>
{% if errors %}
<div class="alert alert-error" data-testid="passenger-error-banner" role="alert">
  Please correct the highlighted fields.
</div>
{% endif %}
<div class="card">
  <form method="post" action="{{ url_for('passenger_details') }}" data-testid="passenger-form" novalidate>
    {% for key, value in selected.items() %}
    <input type="hidden" name="{{ key }}" value="{{ value }}">
    {% endfor %}
    <div class="grid cols-3">
      <div>
        <label for="title">Title</label>
        <select id="title" name="title" data-testid="title-select">
          <option value="">Select</option>
          {% for t in ['Mr', 'Ms', 'Mrs'] %}
          <option value="{{ t }}" {% if form.get('title') == t %}selected{% endif %}>{{ t }}</option>
          {% endfor %}
        </select>
        <span class="error" data-testid="error-title">{{ errors.get('title','') }}</span>
      </div>
      <div>
        <label for="first-name">First name</label>
        <input type="text" id="first-name" name="first_name" data-testid="first-name"
               value="{{ form.get('first_name','') }}" placeholder="As on government ID">
        <span class="error" data-testid="error-first-name">{{ errors.get('first_name','') }}</span>
      </div>
      <div>
        <label for="last-name">Last name</label>
        <input type="text" id="last-name" name="last_name" data-testid="last-name"
               value="{{ form.get('last_name','') }}">
        <span class="error" data-testid="error-last-name">{{ errors.get('last_name','') }}</span>
      </div>
    </div>
    <div class="grid cols-3" style="margin-top:14px">
      <div>
        <label for="dob">Date of birth</label>
        <input type="date" id="dob" name="dob" data-testid="dob"
               max="{{ today }}" value="{{ form.get('dob','') }}">
        <span class="error" data-testid="error-dob">{{ errors.get('dob','') }}</span>
      </div>
      <div>
        <label for="email">Email</label>
        <input type="text" id="email" name="email" data-testid="email"
               value="{{ form.get('email','') }}" placeholder="name@example.com">
        <span class="error" data-testid="error-email">{{ errors.get('email','') }}</span>
      </div>
      <div>
        <label for="phone">Mobile number</label>
        <input type="text" id="phone" name="phone" data-testid="phone"
               value="{{ form.get('phone','') }}" maxlength="10" placeholder="10 digits">
        <span class="error" data-testid="error-phone">{{ errors.get('phone','') }}</span>
      </div>
    </div>
    <div class="grid cols-2" style="margin-top:14px">
      <div>
        <label for="seat">Seat preference (optional)</label>
        <select id="seat" name="seat" data-testid="seat-select">
          {% for s in ['No preference', 'Window', 'Aisle', 'Middle'] %}
          <option value="{{ s }}" {% if form.get('seat') == s %}selected{% endif %}>{{ s }}</option>
          {% endfor %}
        </select>
      </div>
    </div>
    <div class="actions">
      <button type="submit" data-testid="continue-button">Continue to payment</button>
      <a class="muted" href="{{ url_for('home') }}" data-testid="cancel-booking">Cancel booking</a>
    </div>
  </form>
</div>
""",
)

PASSENGER_HIDDEN = ("flight", "origin", "destination", "departure_date", "fare", "departure", "arrival")


def _fare_display(fare: str) -> str:
    return f"₹{int(fare):,}" if fare.strip().isdigit() else (fare or "")


@app.route("/passenger", methods=["GET", "POST"])
def passenger_details():
    if request.method == "GET":
        selected = {
            "flight": request.args.get("flight") or "",
            "origin": request.args.get("origin") or "",
            "destination": request.args.get("destination") or "",
            "departure_date": request.args.get("departure_date") or "",
            "departure": request.args.get("departure") or "",
            "arrival": request.args.get("arrival") or "",
            "fare": request.args.get("fare") or "",
        }
        if not selected["flight"]:
            return redirect(url_for("home"))
        return render_template_string(
            PASSENGER, selected=selected, errors={}, form={},
            fare_display=_fare_display(selected["fare"]), today=date.today().isoformat(),
        )

    # POST -------------------------------------------------------------- #
    form = request.form.to_dict()
    selected = {k: form.get(k, "") for k in PASSENGER_HIDDEN}
    errors = validate_passenger(request.form)

    if errors:
        return (
            render_template_string(
                PASSENGER, selected=selected, errors=errors, form=form,
                fare_display=_fare_display(selected["fare"]), today=date.today().isoformat(),
            ),
                        400,
        )

    pnr = make_pnr(f"{form['first_name']} {form['last_name']}", selected["flight"])
    query = {
        "pnr": pnr,
        "flight": selected["flight"],
        "origin": selected["origin"],
        "destination": selected["destination"],
        "departure_date": selected["departure_date"],
        "departure": selected["departure"],
        "arrival": selected["arrival"],
        "fare": _fare_display(selected["fare"]),
        "passenger": f"{form['title']} {form['first_name']} {form['last_name']}",
        "email": form["email"],
        "phone": form["phone"],
        "seat": form.get("seat", "No preference"),
    }
    return redirect(url_for("confirmation", **query))


# --------------------------------------------------------------------------- #
# Confirmation
# --------------------------------------------------------------------------- #

CONFIRMATION = BASE.replace(
    "{% block content %}{% endblock %}",
    """
<h1 data-testid="confirmation-heading">Booking confirmed</h1>
<p class="sub">Your e-ticket has been emailed to {{ b.email }}.</p>
{% if show_banner %}
<div class="alert alert-ok" data-testid="success-banner" role="status">
  Payment of {{ b.fare }} received. Booking reference generated.
</div>
{% endif %}
<div class="card">
  <p class="muted" style="margin:0 0 4px">Booking reference (PNR)</p>
  <p class="pnr" data-testid="booking-reference">{{ b.pnr }}</p>
  <h2>Itinerary</h2>
  <dl class="summary">
    <dt>Flight</dt><dd data-testid="confirmed-flight">{{ b.flight }}</dd>
    <dt>Route</dt><dd data-testid="confirmed-route">{{ origin.city }} ({{ origin.code }}) → {{ destination.city }} ({{ destination.code }})</dd>
    <dt>Date</dt><dd data-testid="confirmed-date">{{ b.departure_date }}</dd>
    <dt>Departure</dt><dd data-testid="confirmed-departure">{{ b.departure }}</dd>
    <dt>Arrival</dt><dd data-testid="confirmed-arrival">{{ b.arrival }}</dd>
    <dt>Passenger</dt><dd data-testid="confirmed-passenger">{{ b.passenger }}</dd>
    <dt>Seat</dt><dd data-testid="confirmed-seat">{{ b.seat }}</dd>
    <dt>Fare paid</dt><dd data-testid="confirmed-fare">{{ b.fare }}</dd>
  </dl>
  <div class="actions">
    <a href="{{ url_for('home') }}"><button type="button" data-testid="book-another">Book another flight</button></a>
  </div>
</div>
""",
)


@app.route("/confirmation", methods=["GET"])
def confirmation():
    b = {k: request.args.get(k, "") for k in ("pnr", "flight", "origin", "destination",
                                              "departure_date", "departure", "arrival",
                                              "fare", "passenger", "email", "phone", "seat")}
    if not b["pnr"] or b["origin"] not in CITY_BY_CODE or b["destination"] not in CITY_BY_CODE:
        return redirect(url_for("home"))
    return render_template_string(
        CONFIRMATION,
        b=b,
        origin=CITY_BY_CODE[b["origin"]],
        destination=CITY_BY_CODE[b["destination"]],
        show_banner=True,
    )


# --------------------------------------------------------------------------- #
# Login
# --------------------------------------------------------------------------- #

LOGIN = BASE.replace(
    "{% block content %}{% endblock %}",
    """
<h1>Login</h1>
<p class="sub">Members earn 5% SkyMiles on every booking.</p>
{% if error %}
<div class="alert alert-error" data-testid="login-error" role="alert">{{ error }}</div>
{% endif %}
{% if success %}
<div class="alert alert-ok" data-testid="login-success" role="status">{{ success }}</div>
{% endif %}
<div class="card" style="max-width:420px">
  <form method="post" action="{{ url_for('login') }}" data-testid="login-form" novalidate>
    <div style="margin-bottom:14px">
      <label for="username">Email</label>
      <input type="text" id="username" name="username" data-testid="username"
             value="{{ form.get('username','') }}" placeholder="passenger@skywings.test">
    </div>
    <div style="margin-bottom:18px">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" data-testid="password">
    </div>
    <button type="submit" data-testid="login-button">Login</button>
  </form>
</div>
<p class="muted" style="margin-top:14px">Demo credentials: {{ demo_user }} / {{ demo_pass }}</p>
""",
)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template_string(
            LOGIN, error=None, success=None, form={}, demo_user=DEMO_USER["username"],
            demo_pass=DEMO_USER["password"],
        )
    form = request.form.to_dict()
    username = (form.get("username") or "").strip()
    password = (form.get("password") or "").strip()
    if not username or not password:
        error, status = MESSAGES["login_required"], 400
    elif username != DEMO_USER["username"] or password != DEMO_USER["password"]:
        error, status = MESSAGES["login_invalid"], 401
    else:
        error, status = None, 200
    success = "Logged in as passenger@skywings.test" if not error else None
    return (
        render_template_string(
            LOGIN, error=error, success=success, form=form,
            demo_user=DEMO_USER["username"], demo_pass=DEMO_USER["password"],
        ),
        status,
    )


@app.route("/health")
def health():
    return {"status": "ok", "app": "skywings-demo"}


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)
