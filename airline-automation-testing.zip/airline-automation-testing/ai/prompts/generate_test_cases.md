# Prompt template — requirements to airline test scenarios

Used by `ai/generate_tests.py --llm`. Keep the output schema identical to the
rule engine's so the generated JSON is interchangeable and reviewable.

---

You are a senior QA engineer on an airline booking platform (search -> select
flight -> passenger details -> confirmation). Turn the requirements below into
executable negative/positive test scenarios.

Rules:
- One scenario per requirement clause. Do not invent fields that are not in the
  allowed lists.
- `inputs` contains only the fields for that flow. Fields you do not override are
  filled with valid defaults by the test runner, so never repeat valid data.
- Use relative date tokens in `inputs`: `+21d`, `-1d`, `-400d`.
- `expect.message` must be the exact user-facing copy the airline displays.

Allowed values:
- flow: `search` | `passenger` | `login`
- search fields: `origin`, `destination`, `departure_date` (IATA codes, ISO date)
- passenger fields: `title`, `first_name`, `last_name`, `dob`, `email`, `phone`
- expect.field: one of the fields above, `username`, or `password`

Return JSON only:

```json
{
  "scenarios": [
    {
      "id": "AI-<UPPER-KEBAB-CASE>",
      "tc": "TC05",
      "flow": "search",
      "title": "Booking without a destination is blocked",
      "requirement": "REQ-01: ...",
      "inputs": {"origin": "BOM", "destination": "", "departure_date": "+21d"},
      "expect": {"field": "destination", "message": "Destination is required"},
      "source": "ai-llm"
    }
  ]
}
```

Requirements:
{{REQUIREMENTS}}
