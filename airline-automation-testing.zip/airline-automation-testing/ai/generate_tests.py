#!/usr/bin/env python3
"""
AI-augmented test generation: natural-language requirements -> executable scenarios.

Two modes:

  rule mode (default, no API key, deterministic, CI-safe)
      A small intent-matching engine reads ``ai/requirements/booking_requirements.txt``,
      maps each English sentence onto a booking flow, a field, and the validation
      message the application is expected to display, and writes
      ``test_data/ai_scenarios.json``. ``tests/test_ai_generated.py`` then executes
      every scenario as a normal Selenium test.

  llm mode (``--llm``)
      Same contract, but the scenarios are proposed by an LLM using the prompt in
      ``ai/prompts/generate_test_cases.md``. Requires OPENAI_API_KEY. The response
      is validated against the same schema before it is trusted, so a hallucinated
      field name fails loudly instead of producing a mystery test failure.

Usage:
    python ai/generate_tests.py
    python ai/generate_tests.py --llm
    python ai/generate_tests.py --out test_data/ai_scenarios.json
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.server import MESSAGES  # noqa: E402  (single source of truth for copy)

REQUIREMENTS = ROOT / "ai" / "requirements" / "booking_requirements.txt"
DEFAULT_OUT = ROOT / "test_data" / "ai_scenarios.json"
MARKDOWN_OUT = ROOT / "reports" / "ai_test_cases.md"
PROMPT_FILE = ROOT / "ai" / "prompts" / "generate_test_cases.md"

SEARCH_FIELDS = {"origin", "destination", "departure_date"}
PASSENGER_FIELDS = {"title", "first_name", "last_name", "dob", "email", "phone"}
VALID_FLOWS = {"search", "passenger", "login"}
VALID_FIELDS = SEARCH_FIELDS | PASSENGER_FIELDS | {"username", "password"}


# --------------------------------------------------------------------------- #
# Rule engine: English intent -> scenario contract
# --------------------------------------------------------------------------- #

def _scenario(sid, tc, flow, title, inputs, field, message, requirement, rationale):
    return {
        "id": sid,
        "tc": tc,
        "flow": flow,
        "title": title,
        "requirement": requirement,
        "rationale": rationale,
        "inputs": inputs,
        "expect": {"field": field, "message": message},
        "source": "ai-rule-engine",
    }


RULES = [
    {
        "id": "SEARCH-DESTINATION-MISSING",
        "tc": "TC05",
        "flow": "search",
        "any": [r"without (entering|selecting)?\s*(their )?destination", r"no destination", r"missing destination"],
        "title": "Search is blocked when the destination is not selected",
        "inputs": {"origin": "BOM", "destination": "", "departure_date": "+21d"},
        "field": "destination",
        "message": "destination_required",
        "rationale": "Brief's canonical negative case: destination is mandatory.",
    },
    {
        "id": "SEARCH-ORIGIN-MISSING",
        "tc": "TC05",
        "flow": "search",
        "any": [r"without (selecting|entering)?\s*(an )?origin", r"no origin", r"missing origin"],
        "title": "Search is blocked when the origin is not selected",
        "inputs": {"origin": "", "destination": "DEL", "departure_date": "+21d"},
        "field": "origin",
        "message": "origin_required",
        "rationale": "Both ends of the route are mandatory; test them independently.",
    },
    {
        "id": "SEARCH-DATE-MISSING",
        "tc": "TC03",
        "flow": "search",
        "any": [r"without (choosing|selecting)?\s*(a )?departure date", r"no (departure )?date", r"missing date"],
        "title": "Search is blocked when no departure date is chosen",
        "inputs": {"origin": "BOM", "destination": "DEL", "departure_date": ""},
        "field": "departure_date",
        "message": "date_required",
        "rationale": "Date drives fare and availability, so it cannot be optional.",
    },
    {
        "id": "SEARCH-DATE-PAST",
        "tc": "TC03",
        "flow": "search",
        "any": [r"date in the past", r"past date", r"yesterday"],
        "title": "A past departure date is rejected",
        "inputs": {"origin": "BOM", "destination": "DEL", "departure_date": "-1d"},
        "field": "departure_date",
        "message": "date_past",
        "rationale": "Boundary on the lower edge of the date range.",
    },
    {
        "id": "SEARCH-SAME-CITY",
        "tc": "TC02",
        "flow": "search",
        "any": [r"same city", r"origin (and|equals) destination", r"identical origin"],
        "title": "Origin and destination may not be identical",
        "inputs": {"origin": "DEL", "destination": "DEL", "departure_date": "+21d"},
        "field": "destination",
        "message": "same_city",
        "rationale": "Cross-field validation: individually valid, jointly invalid.",
    },
    {
        "id": "PASSENGER-EMAIL-NO-AT",
        "tc": "TC08",
        "flow": "passenger",
        "any": [r"email[^.]*\b(without|missing)\b[^.]*@", r"email[^.]*\bmissing the @\b"],
        "title": "Email without @ is rejected",
        "inputs": {"email": "rahul.sharma.example.com"},
        "field": "email",
        "message": "email_invalid",
        "rationale": "Structural email validation; ticket delivery depends on it.",
    },
    {
        "id": "PASSENGER-EMAIL-NO-TLD",
        "tc": "TC08",
        "flow": "passenger",
        "any": [r"email[^.]*domain suffix", r"email[^.]*without a (dot|tld)"],
        "title": "Email without a domain suffix is rejected",
        "inputs": {"email": "rahul@example"},
        "field": "email",
        "message": "email_invalid",
        "rationale": "Rejects technically-parsed but undeliverable addresses.",
    },
    {
        "id": "PASSENGER-PHONE-ALPHA",
        "tc": "TC08",
        "flow": "passenger",
        "any": [r"(mobile|phone)[^.]*letters", r"(mobile|phone)[^.]*alphabetic"],
        "title": "Mobile number containing letters is rejected",
        "inputs": {"phone": "abcdefghij"},
        "field": "phone",
        "message": "phone_invalid",
        "rationale": "Type validation on a numeric field.",
    },
    {
        "id": "PASSENGER-PHONE-SHORT",
        "tc": "TC08",
        "flow": "passenger",
        "any": [
            r"(mobile|phone)[^.]*(shorter|fewer)[^.]*(ten|10|\d)",
            r"(mobile|phone)[^.]*less than (ten|10)",
        ],
        "title": "Mobile number shorter than 10 digits is rejected",
        "inputs": {"phone": "12345"},
        "field": "phone",
        "message": "phone_invalid",
        "rationale": "Length boundary below the valid range.",
    },
    {
        "id": "PASSENGER-FIRST-NAME-DIGITS",
        "tc": "TC08",
        "flow": "passenger",
        "any": [r"digits[^.]*first name", r"first name[^.]*digits"],
        "title": "Digits in the first name are rejected",
        "inputs": {"first_name": "Rahul123"},
        "field": "first_name",
        "message": "first_name_invalid",
        "rationale": "Names must match the government ID used at check-in.",
    },
    {
        "id": "PASSENGER-LAST-NAME-SYMBOL",
        "tc": "TC08",
        "flow": "passenger",
        "any": [r"special character[^.]*last name", r"last name[^.]*special character"],
        "title": "Special characters in the last name are rejected",
        "inputs": {"last_name": "Sharma@"},
        "field": "last_name",
        "message": "last_name_invalid",
        "rationale": "Symbols break manifest and API sync with the airline host.",
    },
    {
        "id": "PASSENGER-DOB-FUTURE",
        "tc": "TC08",
        "flow": "passenger",
        "any": [r"date of birth[^.]*future", r"future[^.]*date of birth"],
        "title": "A future date of birth is rejected",
        "inputs": {"dob": "+30d"},
        "field": "dob",
        "message": "dob_future",
        "rationale": "Impossible input; also guards against calendar picker abuse.",
    },
    {
        "id": "PASSENGER-INFANT-ALONE",
        "tc": "TC08",
        "flow": "passenger",
        "any": [r"infant", r"younger than two", r"under two", r"at least 2"],
        "title": "An infant under 2 travelling alone is rejected",
        "inputs": {"dob": "-400d"},
        "field": "dob",
        "message": "dob_min_age",
        "rationale": "Airline business rule: infants must travel with an adult fare.",
    },
    {
        "id": "PASSENGER-TITLE-MISSING",
        "tc": "TC05",
        "flow": "passenger",
        "any": [r"title[^.]*(unselected|not selected|missing)"],
        "title": "Title must be selected before continuing",
        "inputs": {"title": ""},
        "field": "title",
        "message": "title_required",
        "rationale": "Boarding documents require a salutation.",
    },
    {
        "id": "PASSENGER-FORM-EMPTY",
        "tc": "TC05",
        "flow": "passenger",
        "any": [r"completely empty", r"empty form", r"without (entering )?any (details|information)"],
        "title": "Submitting an empty passenger form shows every mandatory error",
        "inputs": {
            "title": "", "first_name": "", "last_name": "",
            "dob": "", "email": "", "phone": "",
        },
        "field": "first_name",
        "message": "first_name_required",
        "rationale": "Whole-form negative case; complements per-field checks.",
    },
]


def parse_requirements(path: Path = REQUIREMENTS) -> list[tuple[str, str]]:
    """Return [(requirement_id, text)] for every non-comment line."""
    items = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = re.match(r"^(REQ-\d+)\s*:\s*(.+)$", line)
        if match:
            items.append((match.group(1), match.group(2).strip()))
        else:
            items.append((f"REQ-{len(items) + 1:02d}", line))
    return items


def generate_from_rules(requirements: list[tuple[str, str]]) -> list[dict]:
    scenarios, seen = [], set()
    for req_id, text in requirements:
        lowered = text.lower()
        for rule in RULES:
            if not any(re.search(pattern, lowered) for pattern in rule["any"]):
                continue
            key = (rule["flow"], json.dumps(rule["inputs"], sort_keys=True), rule["message"])
            if key in seen:
                break
            seen.add(key)
            scenarios.append(
                _scenario(
                    sid=f"AI-{rule['id']}",
                    tc=rule["tc"],
                    flow=rule["flow"],
                    title=rule["title"],
                    inputs=rule["inputs"],
                    field=rule["field"],
                    message=MESSAGES[rule["message"]],
                    requirement=f"{req_id}: {text}",
                    rationale=rule["rationale"],
                )
            )
            break
    return scenarios


# --------------------------------------------------------------------------- #
# Optional LLM mode
# --------------------------------------------------------------------------- #

def generate_from_llm(requirements: list[tuple[str, str]]) -> list[dict]:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise SystemExit("--llm requires OPENAI_API_KEY to be set")

    import urllib.error
    import urllib.request

    prompt = PROMPT_FILE.read_text(encoding="utf-8")
    requirement_block = "\n".join(f"{rid}: {text}" for rid, text in requirements)
    payload = {
        "model": os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
        "messages": [
            {"role": "system", "content": prompt},
            {"role": "user", "content": f"Requirements:\n{requirement_block}"},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.2,
    }
    request = urllib.request.Request(
        os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1") + "/chat/completions",
        data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            body = json.loads(response.read())
    except urllib.error.URLError as exc:
        raise SystemExit(f"LLM request failed: {exc}")

    content = body["choices"][0]["message"]["content"]
    proposals = json.loads(content).get("scenarios", [])
    return [s for s in (validate(s) for s in proposals) if s]


def validate(scenario: dict) -> dict | None:
    """Reject anything the runner could not execute, with a clear reason."""
    required = {"id", "flow", "title", "inputs", "expect"}
    missing = required - scenario.keys()
    if missing:
        print(f"  ! dropped {scenario.get('id', '<no id>')}: missing keys {sorted(missing)}")
        return None
    if scenario["flow"] not in VALID_FLOWS:
        print(f"  ! dropped {scenario['id']}: unknown flow '{scenario['flow']}'")
        return None
    if scenario["flow"] == "search" and not set(scenario["inputs"]) <= SEARCH_FIELDS:
        print(f"  ! dropped {scenario['id']}: unexpected search fields {sorted(scenario['inputs'])}")
        return None
    if scenario["flow"] == "passenger" and not set(scenario["inputs"]) <= PASSENGER_FIELDS:
        print(f"  ! dropped {scenario['id']}: unexpected passenger fields {sorted(scenario['inputs'])}")
        return None
    field = scenario["expect"].get("field")
    if field not in VALID_FIELDS:
        print(f"  ! dropped {scenario['id']}: unknown expected-error field '{field}'")
        return None
    scenario.setdefault("source", "ai-llm")
    scenario.setdefault("tc", "TC08")
    return scenario


# --------------------------------------------------------------------------- #
# Output
# --------------------------------------------------------------------------- #

def resolve_token(value: str) -> str:
    """Resolve '+21d' / '-1d' style relative dates into ISO strings."""
    if isinstance(value, str):
        match = re.fullmatch(r"([+-]\d+)d", value.strip())
        if match:
            return (date.today() + timedelta(days=int(match.group(1)))).isoformat()
    return value


def write_json(scenarios: list[dict], out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    # Deliberately no timestamp: the file must be a pure function of the
    # requirements so CI can fail on drift with `git diff --exit-code`.
    document = {
        "generator": "ai/generate_tests.py",
        "count": len(scenarios),
        "scenarios": scenarios,
    }
    out.write_text(json.dumps(document, indent=2) + "\n", encoding="utf-8")


def write_markdown(scenarios: list[dict], out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# AI-generated test scenarios",
        "",
        f"Generated {len(scenarios)} scenarios from natural-language requirements.",
        "Executed by `tests/test_ai_generated.py`.",
        "",
        "| Scenario | TC | Flow | Requirement | Expected validation |",
        "| --- | --- | --- | --- | --- |",
    ]
    for s in scenarios:
        lines.append(
            f"| `{s['id']}` | {s['tc']} | {s['flow']} | {s['requirement']} | {s['expect']['message']} |"
        )
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--requirements", type=Path, default=REQUIREMENTS)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--llm", action="store_true", help="propose scenarios with an LLM instead of the rule engine")
    args = parser.parse_args()

    requirements = parse_requirements(args.requirements)
    print(f"Read {len(requirements)} requirements from {args.requirements.relative_to(ROOT)}")

    scenarios = generate_from_llm(requirements) if args.llm else generate_from_rules(requirements)
    for scenario in scenarios:
        scenario["inputs"] = {k: resolve_token(v) for k, v in scenario["inputs"].items()}

    write_json(scenarios, args.out)
    write_markdown(scenarios, MARKDOWN_OUT)
    print(f"Generated {len(scenarios)} scenarios -> {args.out.relative_to(ROOT)}")
    print(f"Report -> {MARKDOWN_OUT.relative_to(ROOT)}")
    for scenario in scenarios:
        print(f"  {scenario['id']:<34} {scenario['expect']['field']:<14} {scenario['expect']['message']}")
    return 0 if scenarios else 1


if __name__ == "__main__":
    raise SystemExit(main())
