#!/usr/bin/env python3
"""
AI-augmented analysis of a pytest run.

Three jobs, all offline and deterministic (no API key needed):

  1. Failure triage   — classify each failure (locator drift, timing, validation
                        regression, data, environment) and suggest a next action,
                        so a reviewer reads a diagnosis instead of a stack trace.
  2. Flakiness watch  — flag failures whose signature suggests instability
                        rather than a product defect.
  3. Coverage audit   — parse every validation rule the application can emit
                        (from ``app/server.py``) and every assertion the suite
                        makes, then report rules that nothing tests yet. This is
                        the "automatically identify missing test scenarios" step.

Usage:
    pytest                      # produces reports/junit.xml
    python ai/analyze_failures.py
    python ai/analyze_failures.py --junit reports/junit.xml --out reports/ai_analysis.md
"""

from __future__ import annotations

import argparse
import ast
import json
import re
import sys
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

DEFAULT_JUNIT = ROOT / "reports" / "junit.xml"
DEFAULT_OUT = ROOT / "reports" / "ai_analysis.md"
SERVER = ROOT / "app" / "server.py"
TEST_DIR = ROOT / "tests"
SCENARIO_FILE = ROOT / "test_data" / "ai_scenarios.json"

TC_TITLES = {
    "TC01": "Open airline booking website",
    "TC02": "Search flights between two cities",
    "TC03": "Select departure date",
    "TC04": "Validate passenger information",
    "TC05": "Check mandatory field validation",
    "TC06": "Verify flight search results",
    "TC07": "Validate booking confirmation",
    "TC08": "Test invalid passenger inputs",
}


# --------------------------------------------------------------------------- #
# Failure classification rules
# --------------------------------------------------------------------------- #

CATEGORIES = [
    {
        "name": "Locator drift",
        "match": ["NoSuchElementException", "Unable to locate element", "stale element reference"],
        "cause": "The element the page object expects is not in the DOM.",
        "action": "Check whether the markup or data-testid changed; update the page object, not the test.",
    },
    {
        "name": "Timing / synchronisation",
        "match": ["TimeoutException", "element click intercepted", "ElementNotInteractableException"],
        "cause": "An expected element/state never appeared in time (missing locator or a missing wait).",
        "action": "If the markup changed, fix the page object; if the state arrives late, wait on it explicitly.",
    },
    {
        "name": "Validation regression",
        "match": ["is required", "must be", "cannot be", "invalid", "Enter a valid", "at least"],
        "cause": "Actual validation copy or behaviour differs from the expected message.",
        "action": "Confirm the expected wording in app/server.py MESSAGES; if the copy changed on purpose, update tests; if not, raise a defect.",
    },
    {
        "name": "Behavioural regression",
        "match": ["AssertionError"],
        "cause": "The flow completed but produced a different result than specified.",
        "action": "Compare against the requirement; capture the screenshot in reports/screenshots as evidence.",
    },
    {
        "name": "Environment",
        "match": ["WebDriverException", "session not created", "chrome not reachable", "Connection refused"],
        "cause": "Browser/driver or application server was not reachable.",
        "action": "Re-run; if it persists, check Chromium availability and that the demo app started.",
    },
]

FLAKY_SIGNS = ("TimeoutException", "StaleElementReferenceException", "element click intercepted")


def classify(message: str) -> dict:
    for category in CATEGORIES:
        if any(token.lower() in message.lower() for token in category["match"]):
            return category
    return {
        "name": "Unclassified",
        "cause": "No rule matched this failure signature.",
        "action": "Read the traceback; add a rule to ai/analyze_failures.py once the pattern is known.",
    }


# --------------------------------------------------------------------------- #
# Parsing
# --------------------------------------------------------------------------- #

def parse_junit(path: Path) -> list[dict]:
    if not path.exists():
        raise SystemExit(f"No JUnit report at {path}. Run pytest first.")
    tree = ET.parse(path)
    results = []
    for case in tree.iter("testcase"):
        outcome, message = "passed", ""
        for child in case:
            if child.tag in {"failure", "error"}:
                outcome = "failed"
                message = (child.get("message") or "") + "\n" + (child.text or "")
                break
            if child.tag == "skipped":
                outcome = "skipped"
                message = child.get("message") or ""
        results.append(
            {
                "name": case.get("name") or "",
                "classname": case.get("classname") or "",
                "time": float(case.get("time") or 0),
                "outcome": outcome,
                "message": message.strip(),
                "file": (case.get("file") or "").replace(str(ROOT) + "/", "")
                or "/".join((case.get("classname") or "").split(".")) + ".py",
            }
        )
    return results


def _markers_in(node_src: str) -> set[str]:
    return {m.upper() for m in re.findall(r"pytest\.mark\.(tc\d{2})", node_src)}


def _marker_index() -> dict[str, dict]:
    """Static map of {module: {"module": set, "funcs": {(cls, func): set}}} from tests/."""
    index: dict[str, dict] = {}
    for path in TEST_DIR.glob("test_*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        module_markers: set[str] = set()
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == "pytestmark" for t in node.targets
            ):
                module_markers |= _markers_in(ast.unparse(node))
        funcs: dict[tuple[str | None, str], set[str]] = {}
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_"):
                funcs[(None, node.name)] = module_markers | _markers_in(ast.unparse(node))
            elif isinstance(node, ast.ClassDef):
                class_markers = module_markers | _markers_in(ast.unparse(node))
                for child in node.body:
                    if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and child.name.startswith("test_"):
                        funcs[(node.name, child.name)] = class_markers | _markers_in(ast.unparse(child))
        index[path.stem] = {"module": module_markers, "funcs": funcs}
    return index


def _scenario_tc_map() -> dict[str, str]:
    """AI scenario id -> TC, so generated tests count towards coverage."""
    if not SCENARIO_FILE.exists():
        return {}
    document = json.loads(SCENARIO_FILE.read_text(encoding="utf-8"))
    return {s["id"]: s.get("tc", "") for s in document.get("scenarios", [])}


def markers_for_test(name: str, classname: str) -> set[str]:
    """Resolve the tcNN markers that apply to one JUnit testcase."""
    base_name = name.split("[")[0]
    param = name.split("[", 1)[1].rstrip("]") if "[" in name else ""

    # AI-generated tests: TC comes from the scenario definition.
    if base_name.startswith("test_ai_generated"):
        tc = _scenario_tc_map().get(param, "")
        return {tc.upper()} if tc else set()

    parts = classname.split(".") if classname else []
    index = _marker_index()
    for part in reversed(parts):
        if part in index:
            entry = index[part]
            cls = parts[parts.index(part) + 1] if parts.index(part) + 1 < len(parts) else None
            for (cls_name, func), markers in entry["funcs"].items():
                if func == base_name and (cls is None or cls_name == cls):
                    return markers
            return set(entry["module"])
    return set()


def coverage_by_tc(results: list[dict]) -> dict[str, dict[str, int]]:
    matrix: dict[str, dict[str, int]] = {tc: {"passed": 0, "failed": 0, "skipped": 0} for tc in TC_TITLES}
    for result in results:
        for tc in markers_for_test(result["name"], result["classname"]) or {"unmapped"}:
            matrix.setdefault(tc, {"passed": 0, "failed": 0, "skipped": 0})
            matrix[tc][result["outcome"]] += 1
    return matrix


# --------------------------------------------------------------------------- #
# Coverage audit
# --------------------------------------------------------------------------- #

def app_validation_messages() -> dict[str, str]:
    """Extract MESSAGES = {...} from the application under test."""
    tree = ast.parse(SERVER.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "MESSAGES" for target in node.targets
        ):
            return {k.value: v.value for k, v in zip(node.value.keys, node.value.values)}
    return {}


def asserted_messages() -> set[str]:
    """Every message string referenced anywhere in the tests or AI scenarios."""
    corpus = ""
    for path in TEST_DIR.glob("*.py"):
        corpus += path.read_text(encoding="utf-8")
    if SCENARIO_FILE.exists():
        corpus += SCENARIO_FILE.read_text(encoding="utf-8")
    return corpus


# Validation branches the UI cannot reach, with the reason. Kept explicit so the
# gap report stays honest instead of nagging about defensive code.
UNREACHABLE_FROM_UI = {
    "date_invalid": "The date widget is a native ISO input; malformed strings cannot be typed.",
    "no_flights": "The demo airline schedules every city pair, so the empty state needs a seeded route.",
    "flight_required": "Booking a flight without one redirects to the search page instead.",
    "dob_max_age": "Would need a passenger aged over 120 to trigger.",
}


def gap_analysis(messages: dict[str, str]) -> list[dict]:
    corpus = asserted_messages()
    from app.server import MESSAGES as LIVE  # authoritative, post-import values

    gaps = []
    for key, value in {**messages, **LIVE}.items():
        if value in corpus or f'"{key}"' in corpus or f"'{key}'" in corpus:
            continue
        gaps.append(
            {
                "key": key,
                "message": value,
                "suggestion": f"No test asserts the validation rule '{value}'. "
                f"Add a scenario to ai/requirements/booking_requirements.txt "
                f"(rule key: {key}) and regenerate.",
            }
        )
    return gaps


# --------------------------------------------------------------------------- #
# Report
# --------------------------------------------------------------------------- #

def build_report(results: list[dict]) -> str:
    total = len(results)
    failed = [r for r in results if r["outcome"] == "failed"]
    skipped = [r for r in results if r["outcome"] == "skipped"]
    passed = [r for r in results if r["outcome"] == "passed"]
    duration = sum(r["time"] for r in results)

    lines = [
        "# AI analysis of the airline automation run",
        "",
        f"_Generated {datetime.now().isoformat(timespec='seconds')} by `ai/analyze_failures.py`._",
        "",
        "## 1. Run summary",
        "",
        "| Metric | Value |",
        "| --- | --- |",
        f"| Tests | {total} |",
        f"| Passed | {len(passed)} |",
        f"| Failed | {len(failed)} |",
        f"| Skipped | {len(skipped)} |",
        f"| Wall time (sum of test time) | {duration:.1f}s |",
        f"| Pass rate | {(len(passed) / total * 100) if total else 0:.1f}% |",
        "",
    ]

    # ---- failures ---------------------------------------------------- #
    lines += ["## 2. Failure triage", ""]
    if not failed:
        lines += ["No failures. Nothing to triage — the funnel is green.", ""]
    else:
        grouped: dict[str, list[dict]] = {}
        for result in failed:
            grouped.setdefault(classify(result["message"])["name"], []).append(result)
        lines += ["| Category | Count | Likely cause | Suggested action |", "| --- | --- | --- | --- |"]
        for name, items in grouped.items():
            category = classify(items[0]["message"])
            lines.append(
                f"| {name} | {len(items)} | {category['cause']} | {category['action']} |"
            )
        lines.append("")
        for name, items in grouped.items():
            lines += [f"### {name} ({len(items)})", ""]
            for item in items:
                first_line = next(
                    (ln.strip() for ln in item["message"].splitlines() if ln.strip()), "no message"
                )[:240]
                screenshot = re.sub(r"[^a-zA-Z0-9_-]", "_", item["name"])[-80:]
                lines += [
                    f"- **`{item['name']}`** ({item['file']})",
                    f"  - Signature: `{first_line}`",
                    f"  - Evidence: see `reports/screenshots/` (files matching `{screenshot}`)",
                ]
            lines.append("")

    # ---- flakiness --------------------------------------------------- #
    lines += ["## 3. Flakiness watch", ""]
    flaky = [r for r in failed if any(sign.lower() in r["message"].lower() for sign in FLAKY_SIGNS)]
    if flaky:
        lines += [
            "These failures look like instability rather than product defects — re-run before filing a bug:",
            "",
        ]
        lines += [f"- `{r['name']}`" for r in flaky]
    else:
        lines += ["No timing or staleness signatures detected; failures are deterministic."]
    lines.append("")

    # ---- coverage ---------------------------------------------------- #
    matrix = coverage_by_tc(results)
    lines += ["## 4. Test-case coverage (TC01–TC08)", "", "| TC | Title | Passed | Failed | Status |", "| --- | --- | --- | --- | --- |"]
    for tc, title in TC_TITLES.items():
        counts = matrix.get(tc, {"passed": 0, "failed": 0, "skipped": 0})
        covered = counts["passed"] + counts["failed"] > 0
        status = "FAILING" if counts["failed"] else ("covered" if covered else "**GAP**")
        lines.append(f"| {tc} | {title} | {counts['passed']} | {counts['failed']} | {status} |")
    extra = {tc: c for tc, c in matrix.items() if tc not in TC_TITLES}
    if extra:
        lines.append("")
        for tc, counts in extra.items():
            lines.append(f"- `{tc}`: {counts['passed']} passed, {counts['failed']} failed")
    lines.append("")

    # ---- gaps -------------------------------------------------------- #
    messages = app_validation_messages()
    gaps = gap_analysis(messages)
    lines += [
        "## 5. Missing scenarios identified automatically",
        "",
        f"The application can emit {len(messages)} validation messages; the suite asserts all but {len(gaps)}.",
        "",
    ]
    if gaps:
        genuine = [g for g in gaps if g["key"] not in UNREACHABLE_FROM_UI]
        defensive = [g for g in gaps if g["key"] in UNREACHABLE_FROM_UI]
        if genuine:
            lines += ["### Genuine gaps", "", "| Rule key | Message with no test | Suggested action |", "| --- | --- | --- |"]
            for gap in genuine:
                lines.append(f"| `{gap['key']}` | {gap['message']} | {gap['suggestion']} |")
            lines.append("")
        if defensive:
            lines += [
                "### Defensive branches (not reachable through the UI)",
                "",
                "These exist as server-side safety nets; testing them would require "
                "bypassing the interface, so they are reported for awareness only.",
                "",
                "| Rule key | Message | Why the UI cannot reach it |",
                "| --- | --- | --- |",
            ]
            for gap in defensive:
                lines.append(f"| `{gap['key']}` | {gap['message']} | {UNREACHABLE_FROM_UI[gap['key']]} |")
            lines.append("")
    else:
        lines += [
            "Every validation rule in the application is exercised by at least one automated test.",
            "",
            "Next scenarios worth designing (not yet expressible in the current app):",
            "",
            "- Round-trip / multi-city itineraries.",
            "- Multiple passengers in one booking with per-passenger validation.",
            "- Seat map selection after fare selection.",
            "- Payment failure and retry idempotency (no duplicate PNR).",
        ]
    lines.append("")

    # ---- AI corrections ---------------------------------------------- #
    lines += ["## 6. Generated-test health", ""]
    ai_results = [r for r in results if r["name"].startswith("test_ai_generated")]
    if ai_results:
        ai_failed = [r for r in ai_results if r["outcome"] == "failed"]
        lines += [
            f"- AI-generated scenarios executed: {len(ai_results)}",
            f"- Failing: {len(ai_failed)}",
        ]
        if ai_failed:
            lines += [
                "- A failing generated scenario means either the expectation is wrong "
                "(prompt/rule fix) or the product regressed. Check the requirement text first.",
            ]
    else:
        lines.append("- No AI-generated scenarios were executed in this run (`pytest -m ai`).")
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--junit", type=Path, default=DEFAULT_JUNIT)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--fail-on-regression", action="store_true", help="exit 1 if any test failed")
    args = parser.parse_args()

    results = parse_junit(args.junit)
    report = build_report(results)
    out = args.out if args.out.is_absolute() else (ROOT / args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(report, encoding="utf-8")

    failed = sum(1 for r in results if r["outcome"] == "failed")
    try:
        shown = out.relative_to(ROOT)
    except ValueError:
        shown = out
    print(f"Analysed {len(results)} tests ({failed} failed) -> {shown}")
    if failed:
        print("Triage summary:")
        for result in results:
            if result["outcome"] == "failed":
                print(f"  - {result['name']}: {classify(result['message'])['name']}")
    if args.fail_on_regression and failed:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
