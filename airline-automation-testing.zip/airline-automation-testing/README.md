# Airline Booking Automation Testing — Python + Selenium

End-to-end Selenium automation for an airline booking funnel: **search → select flight → passenger details → confirmation**, built with the Page Object Model, Pytest, and a GitHub Actions pipeline. The suite is AI-augmented: test scenarios are generated from natural-language requirements, and every run is triaged and audited for coverage gaps automatically.

| | |
| --- | --- |
| **Suite size** | 64 tests (49 hand-written + 15 generated) |
| **Last local run** | 64 passed, 0 failed — 102 s, Chrome 156 headless |
| **Application under test** | `app/server.py`, a self-contained Flask demo airline (offline, deterministic) |
| **CI** | `.github/workflows/ci.yml` — smoke → regression → AI analysis → artefacts |

---

## 1. Quick start

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python ai/generate_tests.py      # requirements -> test_data/ai_scenarios.json
pytest -q                        # starts the demo app + Chrome automatically
python ai/analyze_failures.py     # triage + coverage audit -> reports/ai_analysis.md
```

No browser installed? Chromium is required (`apt install chromium chromium-driver` on Debian/Ubuntu, or Chrome). Selenium Manager resolves the driver automatically.

Useful commands:

```bash
make app        # open the demo airline site at http://127.0.0.1:5000
make smoke      # critical-path only (10 tests, ~15 s)
make headed     # watch the browser drive the booking yourself
make demo       # install -> generate scenarios -> full suite -> analysis

pytest -m tc07                  # one project test case
pytest -m "negative and tc08"    # invalid-input cases only
pytest --base-url https://staging.example-airline.test   # point at a real environment
```

### See the application under test

| Search | Flight results |
| --- | --- |
| ![Search widget](docs/app-home.png) | ![Flight results](docs/app-results.png) |

| Passenger details | Booking confirmation |
| --- | --- |
| ![Passenger details](docs/app-passenger.png) | ![Confirmation](docs/app-confirmation.png) |

---

## 2. Test cases and where they live

| TC | What it checks | Tests | Module |
| --- | --- | --- | --- |
| **TC01** | Open airline booking website | 6 | `tests/test_login.py` |
| **TC02** | Search flights between two cities | 15 | `tests/test_flight_search.py` |
| **TC03** | Select departure date (incl. past-date block, today boundary) | 16 | `tests/test_flight_search.py` |
| **TC04** | Validate passenger information | 20 | `tests/test_passenger_details.py` |
| **TC05** | Check mandatory field validation (search form, passenger form, login) | 47 | `test_flight_search.py`, `test_passenger_details.py`, `test_booking.py` |
| **TC06** | Verify flight search results (data integrity, determinism, ordering) | 14 | `tests/test_flight_search.py` |
| **TC07** | Validate booking confirmation (PNR format, itinerary echo, guards) | 9 | `tests/test_booking.py` |
| **TC08** | Test invalid passenger inputs | 28 | `tests/test_passenger_details.py`, `tests/test_ai_generated.py` |

Counts overlap on purpose — a test often proves several cases (e.g. the empty-form test is both TC05 and TC08). Each test carries a `tcNN` marker, so `pytest -m tc05` reproduces those numbers.

---

## 3. Project structure

```
airline-automation-testing/
├── app/
│   └── server.py                  # demo airline app under test (Flask)
├── pages/                         # Page Object Model
│   ├── base_page.py               # waits, locators, data-testid helpers
│   ├── login_page.py
│   ├── flight_search_page.py
│   ├── flight_results_page.py
│   ├── passenger_details_page.py
│   └── booking_confirmation_page.py
├── tests/
│   ├── test_login.py              # TC01 + member login
│   ├── test_flight_search.py      # TC02, TC03, TC05, TC06
│   ├── test_passenger_details.py  # TC04, TC05, TC08
│   ├── test_booking.py            # TC05, TC07
│   └── test_ai_generated.py       # runs the generated scenarios
├── ai/
│   ├── generate_tests.py          # requirements -> executable scenarios
│   ├── analyze_failures.py        # failure triage + coverage audit
│   ├── requirements/booking_requirements.txt
│   └── prompts/                   # LLM prompt templates
├── test_data/ai_scenarios.json    # generated, committed, diff-reviewable
├── docs/                          # screenshots of the app under test
├── reports/                       # report.html, junit.xml, ai_analysis.md, screenshots/
├── conftest.py                    # fixtures: server, driver, page objects, artefacts
├── pytest.ini
├── requirements.txt
├── Makefile
└── .github/workflows/ci.yml
```

---

## 4. Design decisions worth knowing

**A bundled app under test.** The brief's example pointed at `selenium.dev`, which cannot exercise a booking flow. Public demo sites (`blazedemo.com`) are third-party and change without notice. `app/server.py` gives a realistic funnel — mandatory-field validation, itinerary echo, PNR generation, login — that is offline, fast and deterministic. Redirect the suite at any environment with `--base-url`; nothing in `pages/` or `tests/` is coupled to the demo app except the expected validation copy.

**Locators are `data-testid`, not XPath.** Every interaction goes through `BasePage.by_test_id()`. When marketing re-skins the site, selectors survive.

**Explicit waits only.** No `time.sleep`, no implicit wait (`implicitly_wait(0)` is set on purpose). Each page object exposes *intent* — `search_flights()`, `submit_expecting_confirmation()` — and each of those methods waits for the state its caller is about to assert.

**Validation copy lives in one place.** `app/server.py` exposes `MESSAGES`, which tests import. Renaming a message fails one file, not twenty assertions.

**Failures leave evidence.** A `pytest_runtest_makereport` hook saves a screenshot *and* the rendered DOM for every failure into `reports/screenshots/`, and records the URL at failure — that is what the AI triage reads.

Three real bugs the suite caught in itself while being built, all fixed here:

1. Empty error `<span>`s have zero size, so `visibility_of_element_located` could never match them — `text_or_empty()` now checks presence for legitimately-blank elements.
2. Reading an error span right after clicking Submit could inspect the *pre-submit* DOM — the flaky failure moved between runs. `submit_invalid_search()` / `submit_and_observe()` now block on the re-rendered state.
3. `submit()` returned before the redirect to confirmation — replaced by `submit_expecting_confirmation()`.

---

## 5. AI augmentation

Three capabilities, all runnable in CI without a model provider (the deterministic path), with prompts ready for an LLM in `ai/prompts/`.

### 5.1 Requirements → test scenarios

```bash
python ai/generate_tests.py
```

`ai/requirements/booking_requirements.txt` holds plain-English requirements. An intent-matching engine maps each sentence onto a flow, a field and the expected validation message, e.g.

> Input: *"A passenger tries to book a flight without entering their destination."*
> Output: scenario `AI-SEARCH-DESTINATION-MISSING` → flow `search`, `destination=""`, expects *"Destination is required"*.

The output is `test_data/ai_scenarios.json` — **data, not generated code**, so it is reviewable in a pull request, and `tests/test_ai_generated.py` executes every scenario through the normal page objects. 15 of 15 requirements currently map to an executable test.

`python ai/generate_tests.py --llm` swaps the rule engine for an LLM (`OPENAI_API_KEY`, prompt in `ai/prompts/generate_test_cases.md`). Responses are validated against the same schema — an invented field name is dropped with a printed reason rather than becoming a mystery failure.

### 5.2 Failure analysis

```bash
python ai/analyze_failures.py            # writes reports/ai_analysis.md
```

Classifies each failure — locator drift, timing/synchronisation, validation regression, behavioural regression, environment — with the likely cause and the next action, plus a flakiness watch list. A worked example of a triaged run is committed as [`reports/ai_analysis_example_failure.md`](reports/ai_analysis_example_failure.md) (three deliberately broken tests: a bad locator, a wrong expected message, a wrong PNR assertion).

### 5.3 Missing-scenario detection

The analyser AST-parses `MESSAGES` out of the application, then checks every message against everything the tests and scenarios assert. Anything unasserted is reported as a gap, split into **genuine gaps** and **defensive branches the UI cannot reach** (with the reason). Today it reports 19 of 23 rules asserted; the 4 remaining are unreachable through the interface, which is documented rather than pretended.

### 5.4 What the pipeline will not do

The AI layer proposes scenarios and triages evidence; it does not decide whether a defect is real, and it never edits application code. Every generated scenario lands in git as a diff for a human to approve.

---

## 6. CI/CD

`.github/workflows/ci.yml` runs on push, pull request, nightly schedule and manual dispatch:

1. install dependencies, print the Chrome version
2. regenerate scenarios and **fail if `test_data/ai_scenarios.json` is stale**
3. smoke tests (`-m smoke`) as a fast gate
4. full regression with HTML + JUnit reports
5. AI analysis, published into the job summary (`$GITHUB_STEP_SUMMARY`)
6. upload `reports/` as a build artefact for 14 days

---

## 7. Extending the suite

* **New page** → subclass `BasePage`, expose intent methods, add `data-testid` hooks to the app.
* **New validation rule** → add the message to `MESSAGES`, a requirement line, and run `make ai-gen`; the scenario runs automatically.
* **New environment** → `pytest --base-url ...` or `AIRLINE_BASE_URL`; use `CHROME_BIN` / `CHROMEDRIVER_PATH` for custom browser installs.
* **Known-flaky quarantine** → mark `@pytest.mark.flaky` (register in `pytest.ini`) and let `ai/analyze_failures.py` keep reporting the signature.

---

*Demo application and test suite built for the "Airline Booking Automation Testing" project brief. SkyWings is fictional; no real airline systems are contacted.*
