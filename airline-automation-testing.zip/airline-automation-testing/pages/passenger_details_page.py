"""Passenger details form: who is flying, and how we reach them."""

from __future__ import annotations

from pages.base_page import BasePage
from pages.booking_confirmation_page import BookingConfirmationPage

VALID_FIELDS = (
    "title",
    "first_name",
    "last_name",
    "dob",
    "email",
    "phone",
)
MANDATORY_TEXTS = ("first-name", "last-name", "email", "phone", "dob")


class PassengerDetailsPage(BasePage):
    PAGE_PATH = "/passenger"

    # --- loading ------------------------------------------------------- #
    def wait_until_loaded(self) -> "PassengerDetailsPage":
        self.visible("passenger-form")
        return self

    # --- actions ------------------------------------------------------- #
    def fill_first_name(self, value: str) -> "PassengerDetailsPage":
        self.type_text("first-name", value)
        return self

    def fill_last_name(self, value: str) -> "PassengerDetailsPage":
        self.type_text("last-name", value)
        return self

    def fill_email(self, value: str) -> "PassengerDetailsPage":
        self.type_text("email", value)
        return self

    def fill_phone(self, value: str) -> "PassengerDetailsPage":
        self.type_text("phone", value)
        return self

    def fill_dob(self, iso_date: str) -> "PassengerDetailsPage":
        self.set_date("dob", iso_date)
        return self

    def select_title(self, title: str) -> "PassengerDetailsPage":
        self.select_by_value("title-select", title)
        return self

    def select_seat(self, seat: str) -> "PassengerDetailsPage":
        self.select_by_value("seat-select", seat)
        return self

    def fill_passenger(
        self,
        title: str = "Mr",
        first_name: str = "",
        last_name: str = "",
        dob: str = "",
        email: str = "",
        phone: str = "",
        seat: str | None = None,
    ) -> "PassengerDetailsPage":
        """Fills only the values supplied, so negative cases can skip fields."""
        if title:
            self.select_title(title)
        if first_name:
            self.fill_first_name(first_name)
        if last_name:
            self.fill_last_name(last_name)
        if dob:
            self.fill_dob(dob)
        if email:
            self.fill_email(email)
        if phone:
            self.fill_phone(phone)
        if seat:
            self.select_seat(seat)
        return self

    def submit(self) -> "PassengerDetailsPage":
        self.click("continue-button")
        return self

    def cancel(self) -> None:
        self.click("cancel-booking")

    def submit_expecting_confirmation(self) -> BookingConfirmationPage:
        """Submits a valid form and waits for the booking to be confirmed."""
        self.click("continue-button")
        return BookingConfirmationPage(self.driver, self.base_url, self.timeout).wait_until_loaded()

    def submit_and_observe(self) -> bool:
        """Clicks Continue; True if validation blocked us, False if we navigated on.

        Used by data-driven negative tests that must not assume the outcome.
        """
        from selenium.common.exceptions import TimeoutException

        self.click("continue-button")
        try:
            self.wait.until(
                lambda d: d.find_elements(*self.by_test_id("passenger-error-banner"))
                or "/confirmation" in d.current_url
            )
        except TimeoutException:
            pass
        return "/confirmation" not in self.current_url

    def submit_and_expect_error(self) -> "PassengerDetailsPage":
        self.submit()
        self.visible("passenger-error-banner")
        return self

    # --- state --------------------------------------------------------- #
    @property
    def summary(self) -> str:
        return self.text_of("selected-flight-summary")

    @property
    def error_banner_visible(self) -> bool:
        return self.is_visible("passenger-error-banner", timeout=2)

    def errors(self) -> dict[str, str]:
        return {
            field: self.field_error(field)
            for field in ("title", "first_name", "last_name", "dob", "email", "phone")
        }

    def all_errors(self) -> list[str]:
        return [m for m in self.errors().values() if m]

    @property
    def form_values(self) -> dict[str, str]:
        return {
            "first_name": self.value_of("first-name"),
            "last_name": self.value_of("last-name"),
            "email": self.value_of("email"),
            "phone": self.value_of("phone"),
        }
