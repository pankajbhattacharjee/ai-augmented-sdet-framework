"""Flight results page: the schedule table returned for a route + date."""

from __future__ import annotations

import re

from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC

from pages.base_page import BasePage
from pages.passenger_details_page import PassengerDetailsPage


class FlightResultsPage(BasePage):
    PAGE_PATH = "/flights"

    # --- loading ------------------------------------------------------- #
    def wait_until_loaded(self) -> "FlightResultsPage":
        """Waits for either the results table or the empty-state message."""
        self.wait.until(
            lambda d: d.find_elements(*self.by_test_id("flight-results"))
            or d.find_elements(*self.by_test_id("no-flights-message"))
        )
        return self

    # --- state --------------------------------------------------------- #
    @property
    def has_results(self) -> bool:
        return self.is_present("flight-results", timeout=2)

    @property
    def no_flights_message(self) -> str:
        return self.text_of("no-flights-message") if self.is_present("no-flights-message", 2) else ""

    @property
    def result_count(self) -> int:
        return len(self.driver.find_elements(*self.by_test_id("flight-row")))

    @property
    def displayed_count(self) -> int:
        return int(self.text_of("result-count"))

    @property
    def route_summary(self) -> str:
        return self.text_of("route-summary")

    def flight_numbers(self) -> list[str]:
        return [row.get_attribute("data-flight-number") for row in self.rows()]

    def rows(self) -> list[WebElement]:
        self.wait.until(EC.presence_of_element_located(self.by_test_id("flight-results")))
        return self.driver.find_elements(*self.by_test_id("flight-row"))

    def cell(self, row: WebElement, test_id: str) -> str:
        return row.find_element(*self.by_test_id(test_id)).text.strip()

    def flights(self) -> list[dict[str, str]]:
        """Structured view of the schedule table — used for data assertions."""
        parsed = []
        for row in self.rows():
            parsed.append(
                {
                    "number": self.cell(row, "flight-number"),
                    "departure": self.cell(row, "flight-departure"),
                    "arrival": self.cell(row, "flight-arrival"),
                    "duration": self.cell(row, "flight-duration"),
                    "stops": self.cell(row, "flight-stops"),
                    "aircraft": self.cell(row, "flight-aircraft"),
                    "fare": self.cell(row, "flight-fare"),
                    "fare_value": self.fare_value(self.cell(row, "flight-fare")),
                }
            )
        return parsed

    @staticmethod
    def fare_value(fare_text: str) -> int:
        digits = re.sub(r"[^\d]", "", fare_text)
        return int(digits) if digits else 0

    def row_for(self, flight_number: str) -> WebElement:
        for row in self.rows():
            if row.get_attribute("data-flight-number") == flight_number:
                return row
        raise AssertionError(f"Flight {flight_number} not present in results: {self.flight_numbers()}")

    # --- actions ------------------------------------------------------- #
    def select_flight(self, flight_number: str) -> PassengerDetailsPage:
        row = self.row_for(flight_number)
        button = row.find_element(*self.by_test_id("select-flight"))
        self.driver.execute_script("arguments[0].scrollIntoView({block:'center'});", button)
        button.click()
        return PassengerDetailsPage(self.driver, self.base_url).wait_until_loaded()

    def select_first_flight(self) -> PassengerDetailsPage:
        return self.select_flight(self.flight_numbers()[0])
