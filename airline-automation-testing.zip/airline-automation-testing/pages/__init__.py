"""Page objects for the SkyWings demo airline booking application."""

from pages.base_page import BasePage
from pages.booking_confirmation_page import BookingConfirmationPage
from pages.flight_results_page import FlightResultsPage
from pages.flight_search_page import FlightSearchPage
from pages.login_page import LoginPage
from pages.passenger_details_page import PassengerDetailsPage

__all__ = [
    "BasePage",
    "BookingConfirmationPage",
    "FlightResultsPage",
    "FlightSearchPage",
    "LoginPage",
    "PassengerDetailsPage",
]
