"""Home page: the flight search widget (origin / destination / departure date)."""

from __future__ import annotations

from pages.base_page import BasePage
from pages.flight_results_page import FlightResultsPage


class FlightSearchPage(BasePage):
    PAGE_PATH = "/"

    MANDATORY_FIELDS = ("origin", "destination", "departure_date")

    # --- actions ------------------------------------------------------- #
    def open_search(self) -> "FlightSearchPage":
        self.open()
        self.visible("search-form")
        return self

    def select_origin(self, city_code: str) -> "FlightSearchPage":
        self.select_by_value("origin-select", city_code)
        return self

    def select_destination(self, city_code: str) -> "FlightSearchPage":
        self.select_by_value("destination-select", city_code)
        return self

    def enter_departure_date(self, iso_date: str) -> "FlightSearchPage":
        self.set_date("departure-date", iso_date)
        return self

    def click_search(self) -> "FlightSearchPage":
        self.click("search-button")
        return self

    def click_search_for_results(self) -> FlightResultsPage:
        """Submits the widget and returns the results page (happy path only)."""
        self.click("search-button")
        return FlightResultsPage(self.driver, self.base_url).wait_until_loaded()

    def search_flights(self, origin: str, destination: str, iso_date: str) -> FlightResultsPage:
        """Happy-path search: fills the widget and returns the results page."""
        self.open_search()
        self.select_origin(origin)
        self.select_destination(destination)
        self.enter_departure_date(iso_date)
        self.click_search()
        return FlightResultsPage(self.driver, self.base_url).wait_until_loaded()

    def submit_invalid_search(
        self, origin: str = "", destination: str = "", departure_date: str = ""
    ) -> "FlightSearchPage":
        """Submits whatever was supplied, skipping empty fields (negative testing).

        Keyword names match the JSON scenario schema used by the AI-generated
        tests, so a scenario dict can be splatted straight into this method.
        """
        self.open_search()
        if origin:
            self.select_origin(origin)
        if destination:
            self.select_destination(destination)
        if departure_date:
            self.enter_departure_date(departure_date)
        self.click_search()
        # Wait for the re-rendered page: reading the error spans too early would
        # inspect the pre-submit DOM and pass/fail at random.
        self.visible("search-error-banner")
        return self

    # --- state --------------------------------------------------------- #
    @property
    def heading(self) -> str:
        return self.text_of("page-heading")

    @property
    def available_cities(self) -> list[str]:
        return self.options_of("origin-select")

    @property
    def error_banner_visible(self) -> bool:
        return self.is_visible("search-error-banner", timeout=2)

    def errors(self) -> dict[str, str]:
        return {field: self.field_error(field) for field in self.MANDATORY_FIELDS}

    def all_errors(self) -> list[str]:
        return [message for message in self.errors().values() if message]

    @property
    def selected_origin(self) -> str:
        from selenium.webdriver.support.ui import Select

        return Select(self.visible("origin-select")).first_selected_option.get_attribute("value")

    @property
    def departure_date_value(self) -> str:
        return self.value_of("departure-date")
