"""Reusable Selenium behaviour shared by every page object."""

from __future__ import annotations

from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait


class BasePage:
    """Thin wrapper around WebDriverWait helpers.

    Rules this class enforces across the suite:
      * explicit waits only (no time.sleep, no implicit wait) -> no flaky timing;
      * every element is addressed by its ``data-testid`` attribute, never by
        brittle XPath over layout;
      * page objects expose intent (``search``) not mechanics (``click #btn``).
    """

    PAGE_PATH = "/"

    def __init__(self, driver: WebDriver, base_url: str, timeout: int = 10) -> None:
        self.driver = driver
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.wait = WebDriverWait(driver, timeout)

    # ------------------------------------------------------------------ #
    # Navigation
    # ------------------------------------------------------------------ #

    def open(self, path: str | None = None) -> "BasePage":
        self.driver.get(f"{self.base_url}{path or self.PAGE_PATH}")
        return self

    @property
    def current_url(self) -> str:
        return self.driver.current_url

    @property
    def title(self) -> str:
        return self.driver.title

    def waits_for_url(self, fragment: str, timeout: int | None = None) -> bool:
        try:
            WebDriverWait(self.driver, timeout or self.timeout).until(EC.url_contains(fragment))
            return True
        except TimeoutException:
            return False

    # ------------------------------------------------------------------ #
    # Locators
    # ------------------------------------------------------------------ #

    @staticmethod
    def by_test_id(test_id: str) -> tuple[str, str]:
        return By.CSS_SELECTOR, f'[data-testid="{test_id}"]'

    def find(self, test_id: str) -> WebElement:
        return self.wait.until(EC.presence_of_element_located(self.by_test_id(test_id)))

    def find_all(self, test_id: str) -> list[WebElement]:
        return self.wait.until(EC.presence_of_all_elements_located(self.by_test_id(test_id)))

    def visible(self, test_id: str) -> WebElement:
        return self.wait.until(EC.visibility_of_element_located(self.by_test_id(test_id)))

    def clickable(self, test_id: str) -> WebElement:
        return self.wait.until(EC.element_to_be_clickable(self.by_test_id(test_id)))

    def is_present(self, test_id: str, timeout: int = 3) -> bool:
        try:
            WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located(self.by_test_id(test_id))
            )
            return True
        except TimeoutException:
            return False

    def is_visible(self, test_id: str, timeout: int = 3) -> bool:
        try:
            WebDriverWait(self.driver, timeout).until(
                EC.visibility_of_element_located(self.by_test_id(test_id))
            )
            return True
        except TimeoutException:
            return False

    # ------------------------------------------------------------------ #
    # Interactions
    # ------------------------------------------------------------------ #

    def click(self, test_id: str) -> None:
        self.clickable(test_id).click()

    def type_text(self, test_id: str, text: str) -> None:
        element = self.visible(test_id)
        element.clear()
        if text:
            element.send_keys(text)

    def text_of(self, test_id: str) -> str:
        return self.visible(test_id).text.strip()

    def text_or_empty(self, test_id: str, timeout: int = 2) -> str:
        """Text of an element that exists in the DOM but may legitimately be blank.

        Error placeholders are always rendered and only filled on failure, so an
        empty one has zero size and can never satisfy ``visibility_of_element``.
        Presence + ``.text`` is the correct check for that pattern.
        """
        if not self.is_present(test_id, timeout=timeout):
            return ""
        return (self.find(test_id).text or "").strip()

    def select_by_value(self, test_id: str, value: str) -> None:
        Select(self.visible(test_id)).select_by_value(value)

    def select_by_visible_text(self, test_id: str, text: str) -> None:
        Select(self.visible(test_id)).select_by_visible_text(text)

    def options_of(self, test_id: str) -> list[str]:
        return [o.text.strip() for o in Select(self.visible(test_id)).options]

    def set_date(self, test_id: str, iso_date: str) -> None:
        """Fill an ``<input type="date">`` with an ISO (YYYY-MM-DD) value.

        Native date inputs are typed segment-by-segment and the expected input
        format depends on the machine locale, which makes ``send_keys`` flaky on
        CI. Setting ``value`` and firing the events a real keystroke would fire
        keeps the page state identical for the application under test.
        """
        element = self.visible(test_id)
        self.driver.execute_script(
            """
            const [el, val] = arguments;
            el.value = val;
            el.dispatchEvent(new Event('input', {bubbles: true}));
            el.dispatchEvent(new Event('change', {bubbles: true}));
            """,
            element,
            iso_date,
        )

    def value_of(self, test_id: str) -> str:
        return self.visible(test_id).get_attribute("value") or ""

    # ------------------------------------------------------------------ #
    # Error surfaces (shared markup across the app)
    # ------------------------------------------------------------------ #

    def field_error(self, field: str) -> str:
        """Text of ``[data-testid="error-<field>"]``; '' when the span is empty.

        ``field`` accepts either the Python attribute name (``first_name``) or the
        rendered id (``first-name``).
        """
        return self.text_or_empty(f"error-{field.replace('_', '-')}")

    def has_field_error(self, field: str) -> bool:
        return bool(self.field_error(field))
