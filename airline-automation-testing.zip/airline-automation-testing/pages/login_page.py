"""Login page object (member login, reachable from the header)."""

from __future__ import annotations

from pages.base_page import BasePage


class LoginPage(BasePage):
    PAGE_PATH = "/login"

    # --- actions ------------------------------------------------------- #
    def login(self, username: str, password: str) -> "LoginPage":
        if username:
            self.type_text("username", username)
        if password:
            self.type_text("password", password)
        self.click("login-button")
        return self

    def open_login(self) -> "LoginPage":
        self.open()
        self.visible("login-form")
        return self

    # --- state --------------------------------------------------------- #
    @property
    def error_message(self) -> str:
        return self.text_of("login-error") if self.is_present("login-error") else ""

    @property
    def success_message(self) -> str:
        return self.text_of("login-success") if self.is_present("login-success") else ""

    @property
    def is_logged_in(self) -> bool:
        return bool(self.success_message)
