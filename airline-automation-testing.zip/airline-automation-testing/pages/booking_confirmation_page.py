"""Booking confirmation page: PNR + itinerary summary (end of the happy path)."""

from __future__ import annotations

import re

from pages.base_page import BasePage


class BookingConfirmationPage(BasePage):
    PAGE_PATH = "/confirmation"

    def wait_until_loaded(self) -> "BookingConfirmationPage":
        self.visible("booking-reference")
        return self

    # --- state --------------------------------------------------------- #
    @property
    def heading(self) -> str:
        return self.text_of("confirmation-heading")

    @property
    def booking_reference(self) -> str:
        return self.text_of("booking-reference")

    @property
    def is_reference_well_formed(self) -> bool:
        # SkyWings PNRs look like SW + 5 chars from an unambiguous alphabet.
        return bool(re.fullmatch(r"SW[A-Z2-9]{5}", self.booking_reference))

    @property
    def success_banner_visible(self) -> bool:
        return self.is_visible("success-banner", timeout=2)

    def details(self) -> dict[str, str]:
        return {
            "flight": self.text_of("confirmed-flight"),
            "route": self.text_of("confirmed-route"),
            "date": self.text_of("confirmed-date"),
            "departure": self.text_of("confirmed-departure"),
            "arrival": self.text_of("confirmed-arrival"),
            "passenger": self.text_of("confirmed-passenger"),
            "seat": self.text_of("confirmed-seat"),
            "fare": self.text_of("confirmed-fare"),
        }

    # --- actions ------------------------------------------------------- #
    def book_another_flight(self) -> None:
        self.click("book-another")
